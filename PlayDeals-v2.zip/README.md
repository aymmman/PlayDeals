# PlayDeals

Android app that shows Google Play apps, games and Wear OS watch faces that are **temporarily free** or
**genuinely discounted**. Every deal is checked on the Google Play listing itself before it's shown, and
re-checked every couple of hours until it ends.

```
backend/   Python pipeline that finds, verifies and publishes deals (runs on GitHub Actions)
app/       Android app (Kotlin, Jetpack Compose)
docs/      Research, architecture, feed format, test report
.github/   Build APK + Update deals workflows
```

## Setup (one time)

1. Create a **public** GitHub repository (the app reads the deals file from it; no secrets are stored in it).
2. Upload this project to the `main` branch. Uploading the zip is fine, both workflows unzip it.
3. Create the two files from `.github/workflows/` in the repo (`build-apk.yml`, `deals-pipeline.yml`).
4. Actions tab, **Update deals**, **Run workflow**. The first run checks ~95 products and takes about 3 to 5 min.
   It creates the `deals-data` branch with `index.json` and `deals_us.json`.
5. **Build APK** runs on every push to main. Download the APK from **Releases**.

Optional: Reddit as a deal source. Create a Reddit "script" app, then add repository secrets
`REDDIT_CLIENT_ID`, `REDDIT_CLIENT_SECRET`, `REDDIT_USERNAME` (Settings, Secrets and variables, Actions).
The free API tier is for non-commercial use.

## Day-to-day

* Add products to watch: one package ID or Play link per line in `backend/manual_watchlist.txt`.
* Change countries or thresholds: `backend/config.json`.
* Enable a source after you have permission: `backend/sources.json`.
* Check what happened in a run: open the run log, or `health.json` on the `deals-data` branch.

## Run locally (optional)

```
cd backend
python -m pytest -q
python -m playdeals.run --data-dir ../data
```
Android: open the folder in Android Studio, or `gradle assembleDebug` with Gradle 9.3.1 and JDK 17.
Point a local build at your feed with `-PfeedBaseUrl=https://raw.githubusercontent.com/<you>/<repo>/deals-data/`.

## Release signing

`keystore/debug.keystore` is a shared debug key (password `android`) so CI builds install over each other.
Never ship it. For Play, set `KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` in the environment.

## Docs

* `docs/RESEARCH.md`: source inventory, permissions and decisions
* `docs/ARCHITECTURE.md`: design, verification rules, deduplication, costs, limitations, roadmap
* `docs/FEED_API.md`: the JSON contract between backend and app
* `docs/TESTING.md`: what was tested and what still needs a phone
