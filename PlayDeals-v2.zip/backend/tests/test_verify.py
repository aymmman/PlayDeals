from helpers import NOW, make_page
from playdeals.models import Category, Status
from playdeals.play_store import parse_listing
from playdeals.verify import category_for, classify, discount_percent


def snap(**kw):
    return parse_listing(make_page(**kw), "com.t.app", "us", "u", NOW)


def test_paid_becomes_free():
    v = classify(snap(current=0, original=2_990_000), [], False, 10, NOW)
    assert v.status == Status.VERIFIED_FREE and v.discount_percent == 100 and v.original_price_micros == 2_990_000


def test_paid_gets_discount():
    v = classify(snap(current=1_490_000, original=4_990_000), [], False, 10, NOW)
    assert v.status == Status.VERIFIED_DISCOUNT and v.discount_percent == 70


def test_discount_percent_rounds_down():
    assert discount_percent(1_000_000, 3_000_000) == 66


def test_always_free_is_rejected():
    v = classify(snap(current=0), [], False, 10, NOW)
    assert v.status == Status.REJECTED and v.reason == "free_without_paid_history"


def test_not_on_sale_rejected_or_expired():
    assert classify(snap(current=2_000_000), [], False, 10, NOW).status == Status.REJECTED
    assert classify(snap(current=2_000_000), [], True, 10, NOW).status == Status.EXPIRED


def test_tiny_discount_below_threshold():
    v = classify(snap(current=950_000, original=990_000), [], False, 10, NOW)
    assert v.status == Status.REJECTED and v.reason == "discount_below_threshold"


def test_observed_history_counts_as_evidence():
    history = [{"at": NOW - 86400, "price": 3_000_000, "currency": "USD"}]
    v = classify(snap(current=0), history, False, 10, NOW)
    assert v.status == Status.VERIFIED_FREE and v.method == "observed_price_history"


def test_old_or_other_currency_history_ignored():
    old = [{"at": NOW - 40 * 86400, "price": 3_000_000, "currency": "USD"}]
    eur = [{"at": NOW - 3600, "price": 3_000_000, "currency": "EUR"}]
    assert classify(snap(current=0), old, False, 10, NOW).status == Status.REJECTED
    assert classify(snap(current=0), eur, False, 10, NOW).status == Status.REJECTED


def test_failed_snapshot():
    v = classify(parse_listing("<html/>", "a.b", "us", "u", NOW), [], True, 10, NOW)
    assert v.status == Status.VERIFICATION_FAILED


def test_incorrect_promotional_claim_rejected():
    # A source said "free!" but Play shows full price and no sale.
    assert classify(snap(current=4_990_000), [], False, 10, NOW).status == Status.REJECTED


def test_categories():
    assert category_for("GAME_PUZZLE", "x") == Category.GAMES
    assert category_for("WATCH_FACE", "x") == Category.WATCH_FACES
    assert category_for("PERSONALIZATION", "Neon Watch Face") == Category.WATCH_FACES
    assert category_for("TOOLS", "Scanner") == Category.APPS
