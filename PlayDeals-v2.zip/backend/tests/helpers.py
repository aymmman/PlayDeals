"""Build fake Google Play listing pages in the real embedded-data format."""
import json


def _set(tree, path, value):
    node = tree
    for i, idx in enumerate(path):
        while len(node) <= idx:
            node.append(None)
        if i == len(path) - 1:
            node[idx] = value
        else:
            if not isinstance(node[idx], list):
                node[idx] = []
            node = node[idx]


def make_page(title="Test App", developer="Dev Co", genre="GAME_ACTION", current=0, original=None,
              currency="USD", iap="", jsonld_price=None, sale_end=None, ds_key="ds:5", icon="https://img/x.png"):
    data = []
    _set(data, [1, 2, 0, 0], title)
    _set(data, [1, 2, 68, 0], developer)
    _set(data, [1, 2, 95, 0, 3, 2], icon)
    _set(data, [1, 2, 79, 0, 0, 2], genre)
    block = [[current, currency, "price"]]
    if original is not None:
        block.append([original, currency, "orig"])
    _set(data, [1, 2, 57, 0, 0, 0, 0, 1], block)
    if iap:
        _set(data, [1, 2, 19, 0], iap)
    scripts = [f"<script>AF_initDataCallback({{key: '{ds_key}', hash: '1', data:{json.dumps(data)}, sideChannel: {{}}}});</script>"]
    if sale_end is not None:
        d4 = []
        _set(d4, [0, 2, 0, 0, 0, 14, 0, 0], sale_end)
        scripts.append(f"<script>AF_initDataCallback({{key: 'ds:4', hash: '2', data:{json.dumps(d4)}, sideChannel: {{}}}});</script>")
    if jsonld_price is not None:
        ld = {"@type": "SoftwareApplication", "offers": [{"@type": "Offer", "price": jsonld_price, "priceCurrency": currency}]}
        scripts.append(f'<script type="application/ld+json" nonce="x">{json.dumps(ld)}</script>')
    return "<html><body>" + "".join(scripts) + "</body></html>"


class FakePlay:
    """Stands in for PlayClient. pages: {(pkg, country): html | int(http error)}"""

    def __init__(self, pages):
        self.pages = pages
        self.requests_made = 0

    def fetch(self, package_id, country):
        from playdeals.models import PlaySnapshot
        from playdeals.play_store import parse_listing
        self.requests_made += 1
        page = self.pages.get((package_id, country))
        url = f"https://play.google.com/store/apps/details?id={package_id}&gl={country.upper()}"
        if isinstance(page, int):
            return PlaySnapshot(package_id, country, 0, url, ok=False, http_status=page,
                                error="not_found" if page == 404 else f"http_{page}")
        if page is None:
            return PlaySnapshot(package_id, country, 0, url, ok=False, error="TimeoutError")
        return parse_listing(page, package_id, country, url, NOW)


NOW = 1_800_000_000
