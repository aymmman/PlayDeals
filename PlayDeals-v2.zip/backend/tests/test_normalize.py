from playdeals.normalize import extract_package_ids, is_valid_package_id, package_id_from_url, parse_watchlist_line


def test_basic_play_url():
    assert package_id_from_url("https://play.google.com/store/apps/details?id=com.foo.bar") == "com.foo.bar"


def test_url_with_extra_params_and_escaped_amp():
    assert package_id_from_url("https://play.google.com/store/apps/details?hl=en&amp;id=com.foo.bar&gl=US") == "com.foo.bar"


def test_market_link():
    assert package_id_from_url("market://details?id=com.foo.bar") == "com.foo.bar"


def test_rejects_non_play_and_invalid():
    assert package_id_from_url("https://example.com/?id=com.foo.bar") is None
    assert package_id_from_url("https://play.google.com/store/apps/developer?id=Some+Dev") is None
    assert package_id_from_url("https://play.google.com/store/apps/details?id=notapackage") is None
    assert not is_valid_package_id("1com.foo")


def test_extract_dedupes_and_handles_html():
    text = ('<a href="https://play.google.com/store/apps/details?id=com.a.b">x</a> '
            'again https://play.google.com/store/apps/details?id=com.a.b&amp;hl=en and '
            'market://details?id=org.c.d')
    assert extract_package_ids(text) == ["com.a.b", "org.c.d"]


def test_same_package_different_urls_resolve_to_one_id():
    urls = ["https://play.google.com/store/apps/details?id=com.x.y",
            "https://play.google.com/store/apps/details?id=com.x.y&hl=de&gl=DE",
            "market://details?id=com.x.y"]
    assert {package_id_from_url(u) for u in urls} == {"com.x.y"}


def test_watchlist_lines():
    assert parse_watchlist_line("  com.a.b  # comment") == "com.a.b"
    assert parse_watchlist_line("# only comment") is None
    assert parse_watchlist_line("") is None
    assert parse_watchlist_line("https://play.google.com/store/apps/details?id=com.a.b") == "com.a.b"
