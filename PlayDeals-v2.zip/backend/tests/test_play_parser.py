from helpers import NOW, make_page
from playdeals.play_store import parse_listing


def parse(page):
    return parse_listing(page, "com.t.app", "us", "u", NOW)


def test_sale_with_strikethrough():
    s = parse(make_page(current=990_000, original=4_990_000, jsonld_price="0.99"))
    assert s.ok and s.current_price_micros == 990_000 and s.original_price_micros == 4_990_000
    assert s.title == "Test App" and s.developer == "Dev Co" and s.genre_id == "GAME_ACTION"
    assert s.currency == "USD"


def test_free_listing_no_original():
    s = parse(make_page(current=0, jsonld_price="0"))
    assert s.ok and s.current_price_micros == 0 and s.original_price_micros is None


def test_data_under_a_different_ds_key_is_still_found():
    s = parse(make_page(current=1_000_000, ds_key="ds:7"))
    assert s.ok and s.current_price_micros == 1_000_000


def test_jsonld_conflict_is_refused():
    s = parse(make_page(current=0, original=2_000_000, jsonld_price="7.99"))
    assert not s.ok and s.error == "price_conflict_jsonld"


def test_jsonld_matching_list_price_is_accepted():
    s = parse(make_page(current=0, original=2_000_000, jsonld_price="2.00"))
    assert s.ok


def test_page_without_data():
    s = parse("<html>captcha</html>")
    assert not s.ok and s.error == "no_embedded_data"


def test_jsonld_only_fallback():
    page = '<script type="application/ld+json">{"offers":{"price":"1.49","priceCurrency":"EUR"}}</script>'
    s = parse(page)
    assert s.ok and s.current_price_micros == 1_490_000 and s.currency == "EUR"


def test_sale_end_only_accepted_when_sane():
    assert parse(make_page(current=0, original=1, sale_end=NOW + 3600)).sale_ends_at == NOW + 3600
    assert parse(make_page(current=0, original=1, sale_end=NOW - 10)).sale_ends_at is None
    assert parse(make_page(current=0, original=1, sale_end=NOW + 400 * 86400)).sale_ends_at is None


def test_iap_flag():
    assert parse(make_page(iap="$0.99 - $9.99 per item")).has_iap
    assert not parse(make_page()).has_iap
