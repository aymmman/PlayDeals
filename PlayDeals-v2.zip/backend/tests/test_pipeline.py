import json
import os

from helpers import NOW, FakePlay, make_page
from playdeals.connectors.reddit_api import RedditApiConnector, parse_listing as parse_reddit
from playdeals.connectors.rss_feed import parse_feed
from playdeals.models import Candidate, Status
from playdeals.pipeline import Config, build_queue, merge_candidates, publish, run
from playdeals.state import State

import pytest


@pytest.fixture
def env(tmp_path):
    (tmp_path / "manual.txt").write_text("com.game.one\ncom.app.two\n# comment\n")
    sources = [{"id": "manual", "connector_type": "manual_watchlist", "path": "manual.txt", "enabled": True},
               {"id": "reddit", "connector_type": "reddit_oauth_api", "enabled": True},
               {"id": "off", "connector_type": "rss_play_links", "feed_url": "", "enabled": False}]
    cfg = Config(countries=["us"], min_discount_percent=10, grace_hours=12)
    data = tmp_path / "data"
    return tmp_path, sources, cfg, data


def run_once(env, pages, now, cfg=None):
    base, sources, default_cfg, data = env
    fake = FakePlay(pages)
    summary = run(str(data / "state.json"), str(data), sources, str(base), cfg or default_cfg, fake, now)
    feed = json.loads((data / "deals_us.json").read_text())
    return summary, feed, fake


def test_end_to_end_free_and_discount(env, monkeypatch):
    monkeypatch.delenv("REDDIT_CLIENT_ID", raising=False)
    pages = {("com.game.one", "us"): make_page(title="Game One", current=0, original=2_990_000),
             ("com.app.two", "us"): make_page(title="App Two", genre="TOOLS", current=990_000, original=4_990_000)}
    summary, feed, _ = run_once(env, pages, NOW)
    types = {d["package_id"]: (d["deal_type"], d["category"], d["discount_percent"]) for d in feed["deals"]}
    assert types == {"com.game.one": ("FREE", "GAMES", 100), "com.app.two": ("DISCOUNT", "APPS", 80)}
    health = json.loads((env[3] / "health.json").read_text())["sources"]
    assert health["reddit"]["status"] == "skipped" and health["off"]["status"] == "disabled"


def test_feed_never_exposes_sources(env):
    pages = {("com.game.one", "us"): make_page(current=0, original=1_000_000)}
    _, feed, _ = run_once(env, pages, NOW)
    item = feed["deals"][0]
    assert "sources" not in item and "evidence" not in item
    assert item["play_url"] == "https://play.google.com/store/apps/details?id=com.game.one"


def test_always_free_never_published(env):
    pages = {("com.game.one", "us"): make_page(current=0), ("com.app.two", "us"): make_page(current=0)}
    _, feed, _ = run_once(env, pages, NOW)
    assert feed["deals"] == []


def test_deal_expires_when_price_restored(env):
    run_once(env, {("com.game.one", "us"): make_page(current=0, original=1_000_000)}, NOW)
    _, feed, _ = run_once(env, {("com.game.one", "us"): make_page(current=1_000_000)}, NOW + 7200)
    assert feed["deals"] == []
    state = State.load(str(env[3] / "state.json"))
    assert state.records["com.game.one|us"].status == Status.EXPIRED


def test_network_error_keeps_deal_within_grace_then_drops(env):
    run_once(env, {("com.game.one", "us"): make_page(current=0, original=1_000_000)}, NOW)
    _, feed, _ = run_once(env, {}, NOW + 3600)  # fetch fails (timeout)
    assert [d["package_id"] for d in feed["deals"]] == ["com.game.one"]
    state = State.load(str(env[3] / "state.json"))
    assert state.records["com.game.one|us"].status == Status.NEEDS_RECHECK
    _, feed, _ = run_once(env, {}, NOW + 13 * 3600)  # past the 12h grace window
    assert feed["deals"] == []


def test_new_promotion_gets_new_event_id(env):
    _, f1, _ = run_once(env, {("com.game.one", "us"): make_page(current=0, original=1_000_000)}, NOW)
    run_once(env, {("com.game.one", "us"): make_page(current=1_000_000)}, NOW + 86400)
    _, f3, _ = run_once(env, {("com.game.one", "us"): make_page(current=500_000, original=1_000_000)}, NOW + 3 * 86400)
    assert f1["deals"][0]["event_id"] != f3["deals"][0]["event_id"]
    assert f3["deals"][0]["deal_type"] == "DISCOUNT"


def test_same_deal_keeps_event_id_across_runs(env):
    page = {("com.game.one", "us"): make_page(current=0, original=1_000_000)}
    _, a, _ = run_once(env, page, NOW)
    _, b, _ = run_once(env, page, NOW + 7200)
    assert a["deals"][0]["event_id"] == b["deals"][0]["event_id"]


def test_region_specific_prices_are_not_merged(tmp_path):
    (tmp_path / "manual.txt").write_text("com.game.one\n")
    sources = [{"id": "manual", "connector_type": "manual_watchlist", "path": "manual.txt", "enabled": True}]
    cfg = Config(countries=["us", "de"])
    pages = {("com.game.one", "us"): make_page(current=0, original=1_000_000),
             ("com.game.one", "de"): make_page(current=1_190_000, currency="EUR")}
    run(str(tmp_path / "s.json"), str(tmp_path), sources, str(tmp_path), cfg, FakePlay(pages), NOW)
    us = json.loads((tmp_path / "deals_us.json").read_text())["deals"]
    de = json.loads((tmp_path / "deals_de.json").read_text())["deals"]
    assert len(us) == 1 and de == []
    index = json.loads((tmp_path / "index.json").read_text())
    assert [c["code"] for c in index["countries"]] == ["US", "DE"]


def test_not_found_in_region_rejected(env):
    pages = {("com.game.one", "us"): 404}
    run_once(env, pages, NOW)
    state = State.load(str(env[3] / "state.json"))
    assert state.records["com.game.one|us"].status == Status.REJECTED


def test_dedup_multiple_sources_one_record():
    state = State()
    cands = [Candidate("com.a.b", "manual", "u1", NOW), Candidate("com.a.b", "reddit", "u2", NOW),
             Candidate("com.a.b", "reddit", "u2", NOW), Candidate("com.a.b", "rss", "u3", NOW)]
    merge_candidates(state, cands, ["us"], NOW)
    assert list(state.records) == ["com.a.b|us"]
    assert {(s.source_id, s.url) for s in state.records["com.a.b|us"].sources} == {
        ("manual", "u1"), ("reddit", "u2"), ("rss", "u3")}


def test_queue_respects_cap_and_live_first():
    state = State()
    merge_candidates(state, [Candidate(f"com.p.a{i}", "m", "u", NOW) for i in range(10)], ["us"], NOW)
    live = state.records["com.p.a9|us"]
    live.live_status, live.status, live.last_checked = Status.VERIFIED_FREE, Status.VERIFIED_FREE, NOW
    q = build_queue(state, Config(countries=["us"], max_checks_per_run=3), NOW + 60)
    assert len(q) == 3 and q[0].package_id == "com.p.a9"


def test_retention_drops_stale_non_live(env):
    run_once(env, {("com.game.one", "us"): make_page(current=0)}, NOW)
    base, sources, cfg, data = env
    (base / "manual.txt").write_text("")  # nothing mentions it any more
    run(str(data / "state.json"), str(data), sources, str(base), cfg, FakePlay({}), NOW + 31 * 86400)
    assert State.load(str(data / "state.json")).records == {}


def test_missing_watchlist_file_does_not_crash(tmp_path):
    sources = [{"id": "manual", "connector_type": "manual_watchlist", "path": "nope.txt", "enabled": True}]
    summary = run(str(tmp_path / "s.json"), str(tmp_path), sources, str(tmp_path), Config(countries=["us"]), FakePlay({}), NOW)
    assert summary["candidates"] == 0
    health = json.loads((tmp_path / "health.json").read_text())["sources"]
    assert health["manual"]["status"] == "error"


def test_reddit_payload_parsing():
    payload = {"data": {"children": [
        {"data": {"title": "[Game] X $2->Free", "permalink": "/r/googleplaydeals/1",
                  "url": "https://play.google.com/store/apps/details?id=com.x.game", "selftext": ""}},
        {"data": {"title": "Multi", "permalink": "/r/googleplaydeals/2", "url": "https://reddit.com/x",
                  "selftext": "https://play.google.com/store/apps/details?id=com.y.one and "
                              "https://play.google.com/store/apps/details?id=com.x.game"}}]}}
    c = parse_reddit(payload, "reddit", NOW)
    assert [x.package_id for x in c] == ["com.x.game", "com.y.one"]


def test_reddit_skips_without_credentials(monkeypatch):
    monkeypatch.delenv("REDDIT_CLIENT_ID", raising=False)
    monkeypatch.delenv("REDDIT_CLIENT_SECRET", raising=False)
    r = RedditApiConnector({"id": "r"}, ".").collect(NOW)
    assert r.skipped == "missing_credentials" and r.candidates == []


def test_rss_valid_empty_and_malformed():
    rss = """<rss><channel><item><link>https://e.com/1</link>
      <description>&lt;a href="https://play.google.com/store/apps/details?id=com.r.one"&gt;x&lt;/a&gt;</description>
      </item></channel></rss>"""
    assert [c.package_id for c in parse_feed(rss, "s", NOW)] == ["com.r.one"]
    atom = """<feed xmlns="http://www.w3.org/2005/Atom"><entry><link href="https://play.google.com/store/apps/details?id=com.a.two"/></entry></feed>"""
    assert [c.package_id for c in parse_feed(atom, "s", NOW)] == ["com.a.two"]
    assert parse_feed("<rss><channel></channel></rss>", "s", NOW) == []
    with pytest.raises(Exception):
        parse_feed("<rss><channel>", "s", NOW)
