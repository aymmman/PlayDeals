-- Target PostgreSQL schema (e.g. Supabase) for when the JSON state outgrows git.
-- Not used by the MVP. Mirrors backend/playdeals/models.py.

CREATE TABLE products (
    package_id   text PRIMARY KEY CHECK (package_id ~ '^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)+$'),
    title        text,
    developer    text,
    icon_url     text,
    genre_id     text,
    category     text NOT NULL DEFAULT 'APPS' CHECK (category IN ('APPS','GAMES','WATCH_FACES')),
    first_seen   timestamptz NOT NULL DEFAULT now()
);

-- One row per product per store country: the deduplication unit.
CREATE TABLE listings (
    package_id        text NOT NULL REFERENCES products ON DELETE CASCADE,
    country           char(2) NOT NULL,
    status            text NOT NULL CHECK (status IN ('DISCOVERED','PENDING_VERIFICATION','VERIFIED_FREE',
                        'VERIFIED_DISCOUNT','EXPIRED','REJECTED','VERIFICATION_FAILED','NEEDS_RECHECK')),
    currency          char(3),
    current_price     bigint,   -- micros
    last_checked      timestamptz,
    last_success      timestamptz,
    last_source_seen  timestamptz,
    fail_count        int NOT NULL DEFAULT 0,
    last_reason       text,
    PRIMARY KEY (package_id, country)
);
CREATE INDEX listings_due_idx ON listings (status, last_checked);

-- A promotion. A repeat sale of the same product is a new row.
CREATE TABLE deal_events (
    event_id         text PRIMARY KEY,
    package_id       text NOT NULL,
    country          char(2) NOT NULL,
    deal_type        text NOT NULL CHECK (deal_type IN ('FREE','DISCOUNT')),
    price            bigint NOT NULL,
    original_price   bigint NOT NULL CHECK (original_price > price),
    discount_percent int NOT NULL CHECK (discount_percent BETWEEN 1 AND 100),
    price_evidence   text NOT NULL,
    started_at       timestamptz NOT NULL,
    expires_at       timestamptz,
    ended_at         timestamptz,
    FOREIGN KEY (package_id, country) REFERENCES listings ON DELETE CASCADE
);
-- At most one open promotion per product and country.
CREATE UNIQUE INDEX one_open_event ON deal_events (package_id, country) WHERE ended_at IS NULL;
CREATE INDEX active_feed_idx ON deal_events (country, deal_type, started_at DESC) WHERE ended_at IS NULL;

CREATE TABLE source_mentions (
    package_id  text NOT NULL REFERENCES products ON DELETE CASCADE,
    source_id   text NOT NULL,
    url         text NOT NULL,
    first_seen  timestamptz NOT NULL,
    last_seen   timestamptz NOT NULL,
    PRIMARY KEY (package_id, source_id, url)
);

CREATE TABLE price_observations (
    package_id  text NOT NULL,
    country     char(2) NOT NULL,
    observed_at timestamptz NOT NULL,
    price       bigint NOT NULL,
    currency    char(3) NOT NULL,
    method      text NOT NULL,
    evidence_url text NOT NULL,
    PRIMARY KEY (package_id, country, observed_at)
);

CREATE TABLE sources (
    source_id        text PRIMARY KEY,
    name             text NOT NULL,
    connector_type   text NOT NULL,
    config           jsonb NOT NULL DEFAULT '{}',
    enabled          boolean NOT NULL DEFAULT false,
    permission_note  text,
    last_success     timestamptz,
    last_error       text
);

-- Retention: keep 90 days of observations, ended events for 30 days.
-- DELETE FROM price_observations WHERE observed_at < now() - interval '90 days';
-- DELETE FROM deal_events WHERE ended_at < now() - interval '30 days';
