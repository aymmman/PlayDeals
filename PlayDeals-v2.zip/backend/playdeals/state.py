"""Persist pipeline state as JSON.

For the MVP the "database" is a JSON file kept on a separate git branch: zero
cost, fully auditable (every run is a commit), and small (only products that a
source mentioned, never the whole Play catalog). docs/ARCHITECTURE.md explains
when and how to move to PostgreSQL (schema in backend/schema.sql).
"""
from __future__ import annotations

import json
import os
import tempfile
from dataclasses import asdict, fields
from typing import Any

from .models import Category, DealRecord, SourceRef, Status

SCHEMA_VERSION = 1


def record_to_dict(r: DealRecord) -> dict[str, Any]:
    d = asdict(r)
    d["status"] = r.status.value
    d["category"] = r.category.value if r.category else None
    d["live_status"] = r.live_status.value if r.live_status else None
    return d


def record_from_dict(d: dict[str, Any]) -> DealRecord:
    known = {f.name for f in fields(DealRecord)}
    data = {k: v for k, v in d.items() if k in known}
    data["status"] = Status(data.get("status", Status.DISCOVERED.value))
    data["category"] = Category(data["category"]) if data.get("category") else None
    data["live_status"] = Status(data["live_status"]) if data.get("live_status") else None
    data["sources"] = [SourceRef(**s) for s in data.get("sources", [])]
    return DealRecord(**data)


class State:
    def __init__(self, records: dict[str, DealRecord] | None = None, health: dict | None = None):
        self.records: dict[str, DealRecord] = records or {}
        self.health: dict[str, dict] = health or {}

    @classmethod
    def load(cls, path: str) -> "State":
        if not os.path.exists(path):
            return cls()
        with open(path, encoding="utf-8") as fh:
            raw = json.load(fh)
        records = {k: record_from_dict(v) for k, v in raw.get("records", {}).items()}
        return cls(records, raw.get("source_health", {}))

    def save(self, path: str) -> None:
        payload = {
            "schema_version": SCHEMA_VERSION,
            "records": {k: record_to_dict(v) for k, v in sorted(self.records.items())},
            "source_health": self.health,
        }
        write_json_atomic(path, payload)


def write_json_atomic(path: str, payload: Any) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(os.path.abspath(path)), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=1, sort_keys=False)
        fh.write("\n")
    os.replace(tmp, path)
