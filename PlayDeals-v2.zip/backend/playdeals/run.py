"""CLI entry point.

    python -m playdeals.run --data-dir ../deals-data

Reads backend/config.json and backend/sources.json, updates
<data-dir>/state.json and writes the public feed files into <data-dir>.
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time

from .pipeline import Config, run
from .play_store import PlayClient

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Collect, verify and publish Google Play deals.")
    parser.add_argument("--data-dir", required=True, help="Folder for state.json and the public feed")
    parser.add_argument("--config", default=os.path.join(HERE, "config.json"))
    parser.add_argument("--sources", default=os.path.join(HERE, "sources.json"))
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    with open(args.config, encoding="utf-8") as fh:
        raw_cfg = json.load(fh)
    with open(args.sources, encoding="utf-8") as fh:
        sources = json.load(fh)["sources"]

    cfg = Config.from_dict(raw_cfg)
    client = PlayClient(lang=raw_cfg.get("language", "en"), delay_seconds=float(raw_cfg.get("request_delay_seconds", 1.0)))
    summary = run(
        state_path=os.path.join(args.data_dir, "state.json"),
        out_dir=args.data_dir,
        sources=sources,
        base_dir=HERE,
        cfg=cfg,
        client=client,
        now=int(time.time()),
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
