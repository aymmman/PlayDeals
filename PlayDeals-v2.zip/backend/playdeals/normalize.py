"""Turn messy text and links into canonical Google Play package IDs."""
from __future__ import annotations

import html
import re
from urllib.parse import parse_qs, unquote, urlparse

# Android package names: segments of letters/digits/underscore separated by dots,
# at least two segments, each segment starting with a letter or underscore.
PACKAGE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)+$")

# Matches Play links in free text, including market:// links and escaped &amp;
_LINK_RE = re.compile(
    r"(?:https?://play\.google\.com/store/apps/details|market://details)\?[^\s\"'<>)\]]+",
    re.IGNORECASE,
)


def is_valid_package_id(value: str) -> bool:
    return bool(value) and len(value) <= 255 and bool(PACKAGE_RE.match(value))


def package_id_from_url(url: str) -> str | None:
    """Return the package ID from a Play URL, or None if it isn't one."""
    if not url:
        return None
    url = html.unescape(unquote(url.strip()))
    parsed = urlparse(url)
    host = (parsed.netloc or "").lower()
    if parsed.scheme == "market" or host in ("play.google.com", "www.play.google.com"):
        if parsed.scheme != "market" and not parsed.path.startswith("/store/apps/details"):
            return None
        ids = parse_qs(parsed.query).get("id")
        if ids and is_valid_package_id(ids[0].strip()):
            return ids[0].strip()
    return None


def extract_package_ids(text: str) -> list[str]:
    """Find every distinct Play package ID mentioned in a blob of text/HTML."""
    if not text:
        return []
    text = html.unescape(text)
    found: list[str] = []
    for match in _LINK_RE.finditer(text):
        pkg = package_id_from_url(match.group(0))
        if pkg and pkg not in found:
            found.append(pkg)
    return found


def canonical_play_url(package_id: str, country: str | None = None) -> str:
    base = f"https://play.google.com/store/apps/details?id={package_id}"
    return f"{base}&gl={country.upper()}" if country else base


def parse_watchlist_line(line: str) -> str | None:
    """Accept a bare package ID or any Play link; ignore comments and blanks."""
    line = line.split("#", 1)[0].strip()
    if not line:
        return None
    if is_valid_package_id(line):
        return line
    return package_id_from_url(line)
