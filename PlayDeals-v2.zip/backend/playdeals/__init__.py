"""PlayDeals backend: collects, verifies and publishes Google Play deals."""
__version__ = "1.0.0"
