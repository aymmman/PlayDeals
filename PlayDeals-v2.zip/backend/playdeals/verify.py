"""Decide what a Play snapshot proves. Pure functions, no network.

Rules (in order):
1. No trustworthy current price          -> VERIFICATION_FAILED (retry later)
2. Play shows a struck-through price > current
                                          -> VERIFIED_FREE / VERIFIED_DISCOUNT
                                             (method: play_strikethrough)
3. We observed a higher paid price for the same product+country within
   HISTORY_WINDOW and it is now lower    -> VERIFIED_FREE / VERIFIED_DISCOUNT
                                             (method: observed_price_history)
4. Otherwise: free with no proof it was ever paid, or simply not on sale
                                          -> REJECTED (or EXPIRED if it was live)

A discount percent is always rounded DOWN so we never overstate a deal.
"""
from __future__ import annotations

from typing import Optional

from .models import Category, PlaySnapshot, Status, Verdict

HISTORY_WINDOW_SECONDS = 14 * 86400


def discount_percent(current: int, original: int) -> int:
    if original <= 0 or current >= original:
        return 0
    if current == 0:
        return 100
    return int((original - current) * 100 // original)


def max_recent_paid_price(price_history: list[dict], currency: Optional[str], now: int) -> Optional[int]:
    """Highest paid price we ourselves observed recently, in the same currency."""
    best = None
    for point in price_history:
        if now - point.get("at", 0) > HISTORY_WINDOW_SECONDS:
            continue
        if currency and point.get("currency") != currency:
            continue
        price = point.get("price")
        if isinstance(price, int) and price > 0 and (best is None or price > best):
            best = price
    return best


def classify(
    snap: PlaySnapshot,
    price_history: list[dict],
    was_live: bool,
    min_discount_percent: int,
    now: int,
) -> Verdict:
    if not snap.ok or snap.current_price_micros is None:
        return Verdict(Status.VERIFICATION_FAILED, "play_listing", snap.error or "no_price")

    current = snap.current_price_micros
    original = snap.original_price_micros if (snap.original_price_micros or 0) > current else None
    method = "play_strikethrough"
    if original is None:
        observed = max_recent_paid_price(price_history, snap.currency, now)
        if observed is not None and observed > current:
            original, method = observed, "observed_price_history"

    if original is not None:
        pct = discount_percent(current, original)
        if current == 0:
            return Verdict(Status.VERIFIED_FREE, method, "free_now_paid_before", original, 100)
        if pct >= min_discount_percent:
            return Verdict(Status.VERIFIED_DISCOUNT, method, "price_below_previous", original, pct)
        reason = "discount_below_threshold"
    elif current == 0:
        reason = "free_without_paid_history"
    else:
        reason = "not_on_sale"

    return Verdict(Status.EXPIRED if was_live else Status.REJECTED, "play_listing", reason)


def category_for(genre_id: Optional[str], title: Optional[str]) -> Category:
    g = (genre_id or "").upper()
    if g.startswith("GAME"):
        return Category.GAMES
    if g == "WATCH_FACE":
        return Category.WATCH_FACES
    t = (title or "").lower()
    if "watch face" in t or "watchface" in t:
        return Category.WATCH_FACES
    return Category.APPS
