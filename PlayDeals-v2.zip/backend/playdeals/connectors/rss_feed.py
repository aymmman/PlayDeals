"""Generic RSS/Atom connector that harvests Google Play links from a feed.

Intended for feeds we have permission to use (e.g. an approved partner feed).
Only package IDs are extracted; no editorial text is stored or republished.
"""
from __future__ import annotations

import urllib.request
import xml.etree.ElementTree as ET

from ..models import Candidate
from ..normalize import extract_package_ids
from .base import Connector, ConnectorResult

UA = "PlayDealsVerifier/1.0 (+feed reader)"


class RssPlayLinksConnector(Connector):
    connector_type = "rss_play_links"

    def collect(self, now: int) -> ConnectorResult:
        result = ConnectorResult(self.source_id)
        url = self.source.get("feed_url")
        if not url:
            result.ok, result.error = False, "feed_url_missing"
            return result
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=20) as resp:
                body = resp.read().decode("utf-8", errors="replace")
        except Exception as e:
            result.ok, result.error = False, f"{type(e).__name__}: {e}"[:200]
            return result
        try:
            result.candidates = parse_feed(body, self.source_id, now)
        except ET.ParseError as e:
            result.ok, result.error = False, f"malformed_feed: {e}"[:200]
        return result


def parse_feed(body: str, source_id: str, now: int) -> list[Candidate]:
    root = ET.fromstring(body)
    out: list[Candidate] = []
    seen: set[str] = set()
    # Works for RSS <item> and Atom <entry>, with or without namespaces.
    for node in root.iter():
        tag = node.tag.rsplit("}", 1)[-1]
        if tag not in ("item", "entry"):
            continue
        link = ""
        texts = []
        for child in node:
            ctag = child.tag.rsplit("}", 1)[-1]
            if ctag == "link":
                link = child.get("href") or (child.text or "")
                texts.append(link)
            elif ctag in ("description", "content", "encoded", "summary"):
                texts.append(child.text or "")
        for pkg in extract_package_ids(" ".join(texts)):
            if pkg not in seen:
                seen.add(pkg)
                out.append(Candidate(pkg, source_id, link.strip(), now))
    return out
