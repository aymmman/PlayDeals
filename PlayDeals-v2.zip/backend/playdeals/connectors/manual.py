"""Manually curated watchlist: one package ID or Play link per line.

Always permitted: it's our own list. Use it for developer submissions,
links people send you, and paid apps you want watched for future sales.
"""
from __future__ import annotations

import os

from ..models import Candidate
from ..normalize import canonical_play_url, parse_watchlist_line
from .base import Connector, ConnectorResult


class ManualWatchlistConnector(Connector):
    connector_type = "manual_watchlist"

    def collect(self, now: int) -> ConnectorResult:
        path = os.path.join(self.base_dir, self.source.get("path", "manual_watchlist.txt"))
        result = ConnectorResult(self.source_id)
        if not os.path.exists(path):
            result.ok, result.error = False, f"file_not_found:{path}"
            return result
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                pkg = parse_watchlist_line(line)
                if pkg and all(c.package_id != pkg for c in result.candidates):
                    result.candidates.append(Candidate(pkg, self.source_id, canonical_play_url(pkg), now))
        return result
