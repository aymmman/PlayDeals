"""Common connector interface. Every source returns normalized Candidates."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from ..models import Candidate


@dataclass
class ConnectorResult:
    source_id: str
    candidates: list[Candidate] = field(default_factory=list)
    ok: bool = True
    error: Optional[str] = None
    skipped: Optional[str] = None  # e.g. "missing_credentials", "disabled"


class Connector:
    connector_type = "base"

    def __init__(self, source: dict, base_dir: str):
        self.source = source
        self.source_id = source["id"]
        self.base_dir = base_dir

    def collect(self, now: int) -> ConnectorResult:  # pragma: no cover - interface
        raise NotImplementedError


def build_connector(source: dict, base_dir: str) -> Connector:
    from .manual import ManualWatchlistConnector
    from .reddit_api import RedditApiConnector
    from .rss_feed import RssPlayLinksConnector

    types = {
        ManualWatchlistConnector.connector_type: ManualWatchlistConnector,
        RedditApiConnector.connector_type: RedditApiConnector,
        RssPlayLinksConnector.connector_type: RssPlayLinksConnector,
    }
    kind = source.get("connector_type")
    if kind not in types:
        raise ValueError(f"Unknown connector_type '{kind}' for source {source.get('id')}")
    return types[kind](source, base_dir)
