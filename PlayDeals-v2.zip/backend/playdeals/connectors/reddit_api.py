"""r/googleplaydeals through Reddit's OFFICIAL OAuth Data API.

Why not RSS or /new.json? Reddit's robots.txt has disallowed all crawling since
mid-2024 and unauthenticated JSON is blocked, so the only compliant path is the
OAuth API. The free tier is for non-commercial use; a commercial app needs a
separate agreement with Reddit. This connector stays dormant (skipped, not
failed) until REDDIT_CLIENT_ID and REDDIT_CLIENT_SECRET are configured.
"""
from __future__ import annotations

import base64
import json
import os
import urllib.parse
import urllib.request

from ..models import Candidate
from ..normalize import extract_package_ids, package_id_from_url
from .base import Connector, ConnectorResult

TOKEN_URL = "https://www.reddit.com/api/v1/access_token"
API_BASE = "https://oauth.reddit.com"


class RedditApiConnector(Connector):
    connector_type = "reddit_oauth_api"

    def _user_agent(self) -> str:
        user = os.environ.get("REDDIT_USERNAME", "unknown")
        return f"android:playdeals-verifier:v1.0 (by /u/{user})"

    def _token(self, client_id: str, secret: str) -> str:
        auth = base64.b64encode(f"{client_id}:{secret}".encode()).decode()
        data = urllib.parse.urlencode({"grant_type": "client_credentials"}).encode()
        req = urllib.request.Request(
            TOKEN_URL, data=data,
            headers={"Authorization": f"Basic {auth}", "User-Agent": self._user_agent()},
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            return json.loads(resp.read())["access_token"]

    def collect(self, now: int) -> ConnectorResult:
        result = ConnectorResult(self.source_id)
        client_id = os.environ.get("REDDIT_CLIENT_ID")
        secret = os.environ.get("REDDIT_CLIENT_SECRET")
        if not client_id or not secret:
            result.skipped = "missing_credentials"
            return result
        try:
            token = self._token(client_id, secret)
            sub = self.source.get("subreddit", "googleplaydeals")
            url = f"{API_BASE}/r/{sub}/new?limit={int(self.source.get('limit', 100))}&raw_json=1"
            req = urllib.request.Request(
                url, headers={"Authorization": f"bearer {token}", "User-Agent": self._user_agent()}
            )
            with urllib.request.urlopen(req, timeout=20) as resp:
                payload = json.loads(resp.read())
        except Exception as e:
            result.ok, result.error = False, f"{type(e).__name__}: {e}"[:200]
            return result
        result.candidates = parse_listing(payload, self.source_id, now)
        return result


def parse_listing(payload: dict, source_id: str, now: int) -> list[Candidate]:
    out: list[Candidate] = []
    seen: set[str] = set()
    for child in payload.get("data", {}).get("children", []):
        post = child.get("data", {})
        permalink = "https://www.reddit.com" + post.get("permalink", "")
        pkgs = []
        direct = package_id_from_url(post.get("url", ""))
        if direct:
            pkgs.append(direct)
        pkgs += extract_package_ids(post.get("selftext", ""))
        for pkg in pkgs:
            if pkg not in seen:
                seen.add(pkg)
                out.append(Candidate(pkg, source_id, permalink, now, post.get("title")))
    return out
