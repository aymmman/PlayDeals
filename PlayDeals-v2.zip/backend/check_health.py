"""Fail the workflow (and trigger GitHub's failure email) when Google Play
pages could not be read at all, which usually means Play changed its page
format and play_store.py needs updating."""
import json
import sys

summary = json.load(open(sys.argv[1]))["summary"]
checked = summary.get("checked", 0)
ok = summary.get("results", {}).get("_listing_read_ok", 0)
print(f"Checked {checked} listings, read {ok} successfully. Published: {summary.get('published')}")
if checked >= 10 and ok == 0:
    print("::error::No Google Play listing could be parsed. The page format may have changed.")
    sys.exit(1)
if checked >= 10 and ok / checked < 0.5:
    print("::warning::Fewer than half of Google Play listings could be parsed.")
