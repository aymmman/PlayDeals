package com.example.domain

import com.example.data.Category
import com.example.data.Deal
import com.example.data.DealType
import com.example.data.categoryEnum
import com.example.data.type

enum class SortOption { NEWEST, BIGGEST_DISCOUNT, ENDING_SOON, LOWEST_PRICE }

enum class PriceRange(val minMicros: Long, val maxMicros: Long) {
    ANY(0, Long.MAX_VALUE),
    UNDER_1(0, 999_999),
    FROM_1_TO_5(1_000_000, 4_999_999),
    OVER_5(5_000_000, Long.MAX_VALUE),
}

data class DealFilter(
    val type: DealType? = null,
    val category: Category? = null,
    val query: String = "",
    val sort: SortOption = SortOption.NEWEST,
    val priceRange: PriceRange = PriceRange.ANY,
)

object DealFilters {
    /** "Ending soon" only makes sense when Google Play told us an end time. */
    fun canSortByEnding(deals: List<Deal>): Boolean = deals.any { it.expiresAt != null }

    fun apply(deals: List<Deal>, f: DealFilter): List<Deal> {
        val q = f.query.trim().lowercase()
        val filtered = deals.asSequence()
            .filter { f.type == null || it.type == f.type }
            .filter { f.category == null || it.categoryEnum == f.category }
            .filter { it.priceMicros in f.priceRange.minMicros..f.priceRange.maxMicros }
            .filter {
                q.isEmpty() || it.title.lowercase().contains(q) ||
                    (it.developer?.lowercase()?.contains(q) ?: false) || it.packageId.lowercase().contains(q)
            }
            .toList()
        return when (f.sort) {
            SortOption.NEWEST -> filtered.sortedWith(
                compareByDescending<Deal> { it.dealStartedAt ?: it.verifiedAt }.thenBy { it.title.lowercase() })
            SortOption.BIGGEST_DISCOUNT -> filtered.sortedWith(
                compareByDescending<Deal> { it.discountPercent ?: 0 }.thenByDescending { it.originalPriceMicros })
            SortOption.ENDING_SOON -> filtered.sortedWith(
                compareBy<Deal> { it.expiresAt == null }.thenBy { it.expiresAt ?: Long.MAX_VALUE })
            SortOption.LOWEST_PRICE -> filtered.sortedWith(
                compareBy<Deal> { it.priceMicros }.thenByDescending { it.discountPercent ?: 0 })
        }
    }
}
