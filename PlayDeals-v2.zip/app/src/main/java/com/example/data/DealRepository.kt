package com.example.data

import android.content.Context
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class FeedResult(
    val deals: List<Deal>,
    val countries: List<CountryEntry>,
    val country: String,
    val generatedAt: Long,
    val fromCache: Boolean,
    val error: String?,
)

/**
 * Loads the verified feed. Network first; if that fails we fall back to the
 * last copy saved on the device, and say so in the UI.
 */
class DealRepository(
    context: Context,
    private val prefs: Prefs = Prefs(context),
    private val client: FeedClient = FeedClient(BuildConfig.FEED_BASE_URL),
) {
    private val cacheDir = File(context.applicationContext.filesDir, "feed").apply { mkdirs() }

    suspend fun load(preferredCountry: String?): FeedResult = withContext(Dispatchers.IO) {
        var error: String? = null
        var fromCache = false

        val indexJson = try {
            client.fetchText(INDEX).also { cache(INDEX, it) }
        } catch (e: Exception) {
            error = e.message ?: e.javaClass.simpleName
            fromCache = true
            readCache(INDEX)
        }
        val index = indexJson?.let { runCatching { FeedClient.parseIndex(it) }.getOrNull() }
        if (index == null || index.countries.isEmpty()) {
            return@withContext FeedResult(emptyList(), emptyList(), preferredCountry ?: "US", 0, fromCache,
                error ?: "The deals feed isn't available yet.")
        }

        val entry = index.countries.firstOrNull { it.code.equals(preferredCountry, ignoreCase = true) }
            ?: index.countries.first()
        val dealsJson = if (fromCache) readCache(entry.file) else try {
            client.fetchText(entry.file).also { cache(entry.file, it) }
        } catch (e: Exception) {
            error = e.message ?: e.javaClass.simpleName
            fromCache = true
            readCache(entry.file)
        }
        val file = dealsJson?.let { runCatching { FeedClient.parseDeals(it) }.getOrNull() }
        val now = System.currentTimeMillis() / 1000
        val deals = file?.deals.orEmpty().filterNot { it.isExpired(now) }
        if (!fromCache) markSeen(deals)
        FeedResult(deals, index.countries, entry.code, file?.generatedAt ?: index.generatedAt, fromCache,
            if (file == null) (error ?: "Couldn't read the deals feed.") else error)
    }

    /** Deals the user has seen in the app shouldn't trigger a notification later. */
    fun markSeen(deals: List<Deal>) {
        prefs.knownEventIds = prefs.knownEventIds + deals.map { it.eventId }
    }

    private fun cache(name: String, body: String) = runCatching { File(cacheDir, name).writeText(body) }
    private fun readCache(name: String): String? = runCatching { File(cacheDir, name).readText() }.getOrNull()

    companion object {
        const val INDEX = "index.json"
    }
}
