package com.example.data

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Downloads the static JSON feed the backend publishes. No API keys involved. */
class FeedClient(
    private val baseUrl: String,
    private val http: OkHttpClient = defaultHttp,
) {
    fun fetchText(fileName: String): String {
        val request = Request.Builder()
            .url(baseUrl + fileName)
            .header("Cache-Control", "no-cache")
            .build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code} for $fileName")
            return response.body?.string() ?: throw IOException("Empty body for $fileName")
        }
    }

    companion object {
        val moshi: Moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        private val defaultHttp = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()

        fun parseIndex(json: String): FeedIndex =
            moshi.adapter(FeedIndex::class.java).fromJson(json) ?: throw IOException("Bad index")

        fun parseDeals(json: String): DealsFile =
            moshi.adapter(DealsFile::class.java).fromJson(json) ?: throw IOException("Bad deals file")
    }
}
