package com.example.data

import com.squareup.moshi.Json

/** One verified deal, exactly as published by the backend feed (see docs/FEED_API.md). */
data class Deal(
    @Json(name = "event_id") val eventId: String,
    @Json(name = "package_id") val packageId: String,
    val title: String,
    val developer: String? = null,
    @Json(name = "icon_url") val iconUrl: String? = null,
    val category: String = "APPS",
    @Json(name = "deal_type") val dealType: String,
    @Json(name = "price_micros") val priceMicros: Long,
    @Json(name = "original_price_micros") val originalPriceMicros: Long,
    val currency: String? = null,
    @Json(name = "discount_percent") val discountPercent: Int? = null,
    val country: String,
    @Json(name = "verified_at") val verifiedAt: Long,
    @Json(name = "deal_started_at") val dealStartedAt: Long? = null,
    @Json(name = "expires_at") val expiresAt: Long? = null,
    @Json(name = "price_evidence") val priceEvidence: String? = null,
    @Json(name = "has_iap") val hasIap: Boolean = false,
    @Json(name = "play_url") val playUrl: String,
)

data class DealsFile(
    @Json(name = "schema_version") val schemaVersion: Int = 1,
    @Json(name = "generated_at") val generatedAt: Long = 0,
    val country: String = "US",
    val deals: List<Deal> = emptyList(),
)

data class CountryEntry(val code: String, val count: Int = 0, val file: String)

data class FeedIndex(
    @Json(name = "schema_version") val schemaVersion: Int = 1,
    @Json(name = "generated_at") val generatedAt: Long = 0,
    val countries: List<CountryEntry> = emptyList(),
)

/** Minimal copy of a favourite so we can still show it after the deal ends. */
data class FavoriteSnapshot(
    val packageId: String,
    val country: String,
    val title: String,
    val iconUrl: String? = null,
    val playUrl: String,
)

enum class DealType { FREE, DISCOUNT }

enum class Category { APPS, GAMES, WATCH_FACES }

val Deal.type: DealType get() = if (dealType == "FREE") DealType.FREE else DealType.DISCOUNT

val Deal.categoryEnum: Category
    get() = when (category) {
        "GAMES" -> Category.GAMES
        "WATCH_FACES" -> Category.WATCH_FACES
        else -> Category.APPS
    }

val Deal.favoriteKey: String get() = "$packageId|$country"

/** True once the sale end time Google Play reported has passed. */
fun Deal.isExpired(nowSeconds: Long): Boolean = expiresAt != null && expiresAt <= nowSeconds
