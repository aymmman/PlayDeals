package com.example.data

import android.content.Context
import com.squareup.moshi.Types

/** Everything the app stores lives on the device in SharedPreferences. */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("playdeals", Context.MODE_PRIVATE)
    private val snapAdapter = FeedClient.moshi.adapter<List<FavoriteSnapshot>>(
        Types.newParameterizedType(List::class.java, FavoriteSnapshot::class.java)
    )

    var country: String?
        get() = sp.getString(KEY_COUNTRY, null)
        set(value) = sp.edit().putString(KEY_COUNTRY, value).apply()

    var notifyFree: Boolean
        get() = sp.getBoolean(KEY_NOTIFY_FREE, false)
        set(value) = sp.edit().putBoolean(KEY_NOTIFY_FREE, value).apply()

    var notifyDiscount: Boolean
        get() = sp.getBoolean(KEY_NOTIFY_DISCOUNT, false)
        set(value) = sp.edit().putBoolean(KEY_NOTIFY_DISCOUNT, value).apply()

    /** Categories the user wants notifications for. Empty means all. */
    var notifyCategories: Set<String>
        get() = sp.getStringSet(KEY_NOTIFY_CATS, null)?.toSet() ?: Category.values().map { it.name }.toSet()
        set(value) = sp.edit().putStringSet(KEY_NOTIFY_CATS, value).apply()

    var favorites: List<FavoriteSnapshot>
        get() = sp.getString(KEY_FAVORITES, null)?.let { runCatching { snapAdapter.fromJson(it) }.getOrNull() }
            ?: emptyList()
        set(value) = sp.edit().putString(KEY_FAVORITES, snapAdapter.toJson(value)).apply()

    /** Deal events the user already saw in the app or was notified about. */
    var knownEventIds: Set<String>
        get() = sp.getStringSet(KEY_KNOWN_EVENTS, null)?.toSet() ?: emptySet()
        set(value) = sp.edit().putStringSet(KEY_KNOWN_EVENTS, value.toList().takeLast(MAX_KNOWN).toSet()).apply()

    val hasKnownEvents: Boolean get() = sp.contains(KEY_KNOWN_EVENTS)

    companion object {
        private const val KEY_COUNTRY = "country"
        private const val KEY_NOTIFY_FREE = "notify_free"
        private const val KEY_NOTIFY_DISCOUNT = "notify_discount"
        private const val KEY_NOTIFY_CATS = "notify_categories"
        private const val KEY_FAVORITES = "favorites_v1"
        private const val KEY_KNOWN_EVENTS = "known_events"
        private const val MAX_KNOWN = 800
    }
}
