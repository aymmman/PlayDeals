package com.example.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.util.Format

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: MainViewModel) {
    val feed by vm.feed.collectAsStateWithLifecycle()
    val tab by vm.tab.collectAsStateWithLifecycle()
    val controls by vm.controls.collectAsStateWithLifecycle()
    val deals by vm.visibleDeals.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val notify by vm.notify.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    var searching by remember { mutableStateOf(false) }
    val favoriteKeys = favorites.map { "${it.packageId}|${it.country}" }.toSet()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (searching && tab != Tab.SETTINGS) {
                        OutlinedTextField(
                            value = controls.query, onValueChange = vm::setQuery, singleLine = true,
                            placeholder = { Text(stringResource(R.string.search_hint)) },
                            shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth(),
                        )
                    } else {
                        Column {
                            Text(stringResource(R.string.app_name), fontWeight = FontWeight.Bold)
                            Text(
                                Format.countryName(feed.country) + "  " + stringResource(R.string.app_tagline),
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                            )
                        }
                    }
                },
                actions = {
                    if (tab != Tab.SETTINGS) {
                        IconButton(onClick = {
                            if (searching) vm.setQuery("")
                            searching = !searching
                        }) {
                            Icon(
                                if (searching) Icons.Filled.Close else Icons.Filled.Search,
                                contentDescription = stringResource(if (searching) R.string.action_close_search else R.string.action_search),
                            )
                        }
                    }
                    IconButton(onClick = { vm.refresh() }, enabled = !feed.refreshing) {
                        if (feed.refreshing) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Filled.Refresh, contentDescription = stringResource(R.string.action_refresh))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
        bottomBar = {
            NavigationBar {
                NavItem(tab == Tab.FREE, Icons.Filled.CardGiftcard, stringResource(R.string.tab_free)) { vm.selectTab(Tab.FREE) }
                NavItem(tab == Tab.DISCOUNTS, Icons.Filled.LocalOffer, stringResource(R.string.tab_discounts)) { vm.selectTab(Tab.DISCOUNTS) }
                NavItem(tab == Tab.SAVED, Icons.Filled.Favorite, stringResource(R.string.tab_favorites)) { vm.selectTab(Tab.SAVED) }
                NavItem(tab == Tab.SETTINGS, Icons.Filled.Settings, stringResource(R.string.tab_settings)) { vm.selectTab(Tab.SETTINGS) }
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                Tab.FREE, Tab.DISCOUNTS -> DealListScreen(
                    isDiscountTab = tab == Tab.DISCOUNTS, feed = feed, deals = deals, controls = controls,
                    isFavorite = { it.packageId + "|" + it.country in favoriteKeys },
                    onCategory = vm::setCategory, onSort = vm::setSort, onPriceRange = vm::setPriceRange,
                    onOpen = { vm.select(it) }, onToggleFavorite = vm::toggleFavorite, onRetry = { vm.refresh() },
                )
                Tab.SAVED -> SavedScreen(
                    favorites = favorites, activeDeals = feed.deals, query = controls.query,
                    onOpen = { vm.select(it) }, onToggleFavorite = vm::toggleFavorite, onRemove = vm::removeFavorite,
                )
                Tab.SETTINGS -> SettingsScreen(
                    countries = feed.countries, country = feed.country, notify = notify,
                    onCountry = vm::setCountry, onNotify = { f, d, c -> vm.setNotify(f, d, c) },
                )
            }
        }
    }

    selected?.let { deal ->
        DealDetailSheet(
            deal = deal, isFavorite = deal.packageId + "|" + deal.country in favoriteKeys,
            onDismiss = { vm.select(null) }, onToggleFavorite = { vm.toggleFavorite(deal) },
        )
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.NavItem(
    selected: Boolean, icon: ImageVector, label: String, onClick: () -> Unit,
) {
    NavigationBarItem(selected = selected, onClick = onClick, icon = { Icon(icon, contentDescription = null) }, label = { Text(label) })
}
