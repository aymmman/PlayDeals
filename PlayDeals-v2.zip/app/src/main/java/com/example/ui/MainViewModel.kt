package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Category
import com.example.data.CountryEntry
import com.example.data.Deal
import com.example.data.DealRepository
import com.example.data.DealType
import com.example.data.FavoriteSnapshot
import com.example.data.Prefs
import com.example.data.favoriteKey
import com.example.domain.DealFilter
import com.example.domain.DealFilters
import com.example.domain.PriceRange
import com.example.domain.SortOption
import com.example.notify.DealNotifier
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Tab { FREE, DISCOUNTS, SAVED, SETTINGS }

data class FeedUiState(
    val loading: Boolean = true,
    val refreshing: Boolean = false,
    val deals: List<Deal> = emptyList(),
    val countries: List<CountryEntry> = emptyList(),
    val country: String = "US",
    val generatedAt: Long = 0,
    val fromCache: Boolean = false,
    val error: String? = null,
)

data class Controls(
    val category: Category? = null,
    val query: String = "",
    val sort: SortOption = SortOption.NEWEST,
    val priceRange: PriceRange = PriceRange.ANY,
)

data class NotifySettings(val free: Boolean, val discount: Boolean, val categories: Set<String>)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val repo = DealRepository(app, prefs)

    private val _feed = MutableStateFlow(FeedUiState())
    val feed: StateFlow<FeedUiState> = _feed.asStateFlow()

    private val _tab = MutableStateFlow(Tab.FREE)
    val tab: StateFlow<Tab> = _tab.asStateFlow()

    private val _controls = MutableStateFlow(Controls())
    val controls: StateFlow<Controls> = _controls.asStateFlow()

    private val _favorites = MutableStateFlow(prefs.favorites)
    val favorites: StateFlow<List<FavoriteSnapshot>> = _favorites.asStateFlow()

    private val _notify = MutableStateFlow(NotifySettings(prefs.notifyFree, prefs.notifyDiscount, prefs.notifyCategories))
    val notify: StateFlow<NotifySettings> = _notify.asStateFlow()

    private val _selected = MutableStateFlow<Deal?>(null)
    val selected: StateFlow<Deal?> = _selected.asStateFlow()

    /** What the current list tab shows after filters. */
    val visibleDeals: StateFlow<List<Deal>> = combine(_feed, _tab, _controls) { feed, tab, c ->
        val type = when (tab) {
            Tab.FREE -> DealType.FREE
            Tab.DISCOUNTS -> DealType.DISCOUNT
            else -> null
        }
        val sort = if (c.sort == SortOption.ENDING_SOON && !DealFilters.canSortByEnding(feed.deals)) SortOption.NEWEST else c.sort
        val price = if (tab == Tab.DISCOUNTS) c.priceRange else PriceRange.ANY
        DealFilters.apply(feed.deals, DealFilter(type, c.category, c.query, sort, price))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        DealNotifier.sync(app, prefs)
        refresh(initial = true)
    }

    fun refresh(initial: Boolean = false) {
        viewModelScope.launch {
            _feed.update { it.copy(loading = initial || it.deals.isEmpty(), refreshing = !initial) }
            val r = repo.load(prefs.country)
            _feed.value = FeedUiState(
                loading = false, refreshing = false, deals = r.deals, countries = r.countries,
                country = r.country, generatedAt = r.generatedAt, fromCache = r.fromCache, error = r.error,
            )
        }
    }

    fun selectTab(tab: Tab) { _tab.value = tab }
    fun setCategory(category: Category?) = _controls.update { it.copy(category = category) }
    fun setQuery(query: String) = _controls.update { it.copy(query = query) }
    fun setSort(sort: SortOption) = _controls.update { it.copy(sort = sort) }
    fun setPriceRange(range: PriceRange) = _controls.update { it.copy(priceRange = range) }
    fun select(deal: Deal?) { _selected.value = deal }

    fun setCountry(code: String) {
        prefs.country = code
        refresh()
    }

    fun isFavorite(deal: Deal): Boolean = _favorites.value.any { "${it.packageId}|${it.country}" == deal.favoriteKey }

    fun toggleFavorite(deal: Deal) {
        val current = _favorites.value
        val next = if (current.any { "${it.packageId}|${it.country}" == deal.favoriteKey }) {
            current.filterNot { "${it.packageId}|${it.country}" == deal.favoriteKey }
        } else {
            current + FavoriteSnapshot(deal.packageId, deal.country, deal.title, deal.iconUrl, deal.playUrl)
        }
        prefs.favorites = next
        _favorites.value = next
    }

    fun removeFavorite(snapshot: FavoriteSnapshot) {
        val next = _favorites.value.filterNot { it.packageId == snapshot.packageId && it.country == snapshot.country }
        prefs.favorites = next
        _favorites.value = next
    }

    fun setNotify(free: Boolean? = null, discount: Boolean? = null, categories: Set<String>? = null) {
        free?.let { prefs.notifyFree = it }
        discount?.let { prefs.notifyDiscount = it }
        categories?.let { prefs.notifyCategories = it }
        _notify.value = NotifySettings(prefs.notifyFree, prefs.notifyDiscount, prefs.notifyCategories)
        DealNotifier.sync(getApplication(), prefs)
    }
}
