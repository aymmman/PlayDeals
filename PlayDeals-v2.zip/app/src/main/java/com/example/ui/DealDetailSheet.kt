package com.example.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.Deal
import com.example.data.DealType
import com.example.data.categoryEnum
import com.example.data.type
import com.example.util.Format
import com.example.util.Intents
import com.example.util.Times

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DealDetailSheet(deal: Deal, isFavorite: Boolean, onDismiss: () -> Unit, onToggleFavorite: () -> Unit) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val original = Format.price(deal.originalPriceMicros, deal.currency)
    val shareText = if (deal.type == DealType.FREE) {
        stringResource(R.string.share_text_free, deal.title, original, deal.playUrl)
    } else {
        stringResource(R.string.share_text_discount, deal.title, Format.price(deal.priceMicros, deal.currency), original, deal.playUrl)
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).navigationBarsPadding(),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(deal.iconUrl, deal.title, size = 72)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(deal.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    deal.developer?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Text(categoryLabel(deal.categoryEnum), style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = stringResource(if (isFavorite) R.string.action_unsave else R.string.action_save),
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            PriceTag(deal, large = true)
            Spacer(Modifier.height(16.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(R.string.detail_verified, Format.countryName(deal.country), Times.relative(deal.verifiedAt)),
                    style = MaterialTheme.typography.bodyMedium)
                Text(
                    stringResource(
                        if (deal.priceEvidence == "observed_price_history") R.string.detail_evidence_history
                        else R.string.detail_evidence_play,
                        original,
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                )
                deal.expiresAt?.let {
                    Text(stringResource(R.string.ends_on, Times.dateTime(it)), style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold)
                }
                if (deal.hasIap) {
                    Text(stringResource(R.string.has_iap), style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(20.dp))
            Button(onClick = { Intents.openPlay(context, deal.packageId, deal.playUrl) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.action_open_play))
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { Intents.share(context, shareText) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Share, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.action_share))
            }
            Spacer(Modifier.height(16.dp))
            HorizontalDivider()
            Text(stringResource(R.string.detail_disclaimer), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 12.dp))
        }
    }
}
