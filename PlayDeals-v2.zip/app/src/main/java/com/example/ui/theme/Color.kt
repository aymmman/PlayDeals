package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deal colours carry meaning: mint = free, amber = discount. Nothing else uses them.
val FreeMint = Color(0xFF0E8F6A)
val FreeMintSoft = Color(0xFFD7F2E8)
val FreeMintDark = Color(0xFF5FD4AB)
val DiscountAmber = Color(0xFFB45309)
val DiscountAmberSoft = Color(0xFFFCEBD5)
val DiscountAmberDark = Color(0xFFF2A65A)

val Indigo = Color(0xFF3F3CBB)
val IndigoLight = Color(0xFFB9B7FF)

val InkLight = Color(0xFF1A1C2B)
val MutedLight = Color(0xFF5B5F73)
val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF3F4F8)
val SurfaceVariantLight = Color(0xFFE7E9F0)

val InkDark = Color(0xFFECEDF4)
val MutedDark = Color(0xFFA3A7BA)
val SurfaceDark = Color(0xFF1C1F2E)
val BackgroundDark = Color(0xFF121420)
val SurfaceVariantDark = Color(0xFF2A2E40)
