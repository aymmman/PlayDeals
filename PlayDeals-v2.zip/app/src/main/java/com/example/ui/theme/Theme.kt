package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class DealColors(val free: Color, val freeSoft: Color, val discount: Color, val discountSoft: Color)

val LocalDealColors = staticCompositionLocalOf {
    DealColors(FreeMint, FreeMintSoft, DiscountAmber, DiscountAmberSoft)
}

private val LightScheme = lightColorScheme(
    primary = Indigo, onPrimary = Color.White,
    primaryContainer = Color(0xFFE2E1FF), onPrimaryContainer = Color(0xFF1B1870),
    background = BackgroundLight, onBackground = InkLight,
    surface = SurfaceLight, onSurface = InkLight,
    surfaceVariant = SurfaceVariantLight, onSurfaceVariant = MutedLight,
    outline = Color(0xFFC9CCD8),
)

private val DarkScheme = darkColorScheme(
    primary = IndigoLight, onPrimary = Color(0xFF1B1870),
    primaryContainer = Color(0xFF2E2B8F), onPrimaryContainer = Color(0xFFE2E1FF),
    background = BackgroundDark, onBackground = InkDark,
    surface = SurfaceDark, onSurface = InkDark,
    surfaceVariant = SurfaceVariantDark, onSurfaceVariant = MutedDark,
    outline = Color(0xFF3B4056),
)

@Composable
fun MyApplicationTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val dealColors = if (darkTheme) {
        DealColors(FreeMintDark, Color(0xFF0F3B2E), DiscountAmberDark, Color(0xFF43290F))
    } else {
        DealColors(FreeMint, FreeMintSoft, DiscountAmber, DiscountAmberSoft)
    }
    androidx.compose.runtime.CompositionLocalProvider(LocalDealColors provides dealColors) {
        MaterialTheme(colorScheme = if (darkTheme) DarkScheme else LightScheme, typography = Typography, content = content)
    }
}
