package com.example.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.Deal
import com.example.data.FavoriteSnapshot
import com.example.data.favoriteKey
import com.example.util.Intents

@Composable
fun SavedScreen(
    favorites: List<FavoriteSnapshot>,
    activeDeals: List<Deal>,
    query: String,
    onOpen: (Deal) -> Unit,
    onToggleFavorite: (Deal) -> Unit,
    onRemove: (FavoriteSnapshot) -> Unit,
) {
    if (favorites.isEmpty()) {
        MessageState(Icons.Filled.FavoriteBorder, stringResource(R.string.saved_empty_title), stringResource(R.string.saved_empty_body))
        return
    }
    val byKey = activeDeals.associateBy { it.favoriteKey }
    val q = query.trim().lowercase()
    val shown = favorites.filter { q.isEmpty() || it.title.lowercase().contains(q) }
    val active = shown.mapNotNull { byKey["${it.packageId}|${it.country}"] }
    val ended = shown.filter { byKey["${it.packageId}|${it.country}"] == null }
    val context = LocalContext.current

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (active.isNotEmpty()) {
            item { SectionTitle(stringResource(R.string.saved_active)) }
            items(active, key = { "a_" + it.eventId }) { deal ->
                DealCard(deal, true, onClick = { onOpen(deal) }, onToggleFavorite = { onToggleFavorite(deal) })
            }
        }
        if (ended.isNotEmpty()) {
            item { SectionTitle(stringResource(R.string.saved_ended)) }
            items(ended, key = { "e_" + it.packageId + it.country }) { snap ->
                Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(snap.iconUrl, snap.title, size = 48)
                        Spacer(Modifier.width(12.dp))
                        androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                            Text(snap.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(stringResource(R.string.saved_ended_body), style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { Intents.openPlay(context, snap.packageId, snap.playUrl) }) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = stringResource(R.string.action_open_play))
                        }
                        IconButton(onClick = { onRemove(snap) }) {
                            Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.action_unsave))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 4.dp, start = 4.dp))
}
