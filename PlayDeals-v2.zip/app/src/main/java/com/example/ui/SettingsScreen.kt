package com.example.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.R
import com.example.data.Category
import com.example.data.CountryEntry
import com.example.notify.DealNotifier
import com.example.util.Format

@Composable
fun SettingsScreen(
    countries: List<CountryEntry>,
    country: String,
    notify: NotifySettings,
    onCountry: (String) -> Unit,
    onNotify: (free: Boolean?, discount: Boolean?, categories: Set<String>?) -> Unit,
) {
    val context = LocalContext.current
    var denied by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<Pair<Boolean?, Boolean?>?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        denied = !granted
        val p = pending
        if (granted && p != null) onNotify(p.first, p.second, null)
        pending = null
    }

    fun enable(free: Boolean?, discount: Boolean?) {
        val turningOn = free == true || discount == true
        if (turningOn && Build.VERSION.SDK_INT >= 33 && !DealNotifier.canPost(context)) {
            pending = free to discount
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            onNotify(free, discount, null)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Heading(stringResource(R.string.settings_region))
        Body(stringResource(R.string.settings_region_body))
        val list = countries.ifEmpty { listOf(CountryEntry(country, 0, "")) }
        list.forEach { c ->
            Row(
                Modifier.fillMaxWidth().clickable { onCountry(c.code) }.padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = c.code.equals(country, true), onClick = { onCountry(c.code) })
                Text(Format.countryName(c.code))
            }
        }

        Divider()
        Heading(stringResource(R.string.settings_notifications))
        ToggleRow(stringResource(R.string.settings_notify_free), notify.free) { enable(it, null) }
        ToggleRow(stringResource(R.string.settings_notify_discount), notify.discount) { enable(null, it) }
        if (notify.free || notify.discount) {
            Body(stringResource(R.string.settings_notify_categories))
            Category.values().forEach { cat ->
                val checked = cat.name in notify.categories
                Row(
                    Modifier.fillMaxWidth().clickable {
                        onNotify(null, null, if (checked) notify.categories - cat.name else notify.categories + cat.name)
                    },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Checkbox(checked = checked, onCheckedChange = { on ->
                        onNotify(null, null, if (on) notify.categories + cat.name else notify.categories - cat.name)
                    })
                    Text(categoryLabel(cat))
                }
            }
        }
        if (denied) Body(stringResource(R.string.settings_notify_denied))

        Divider()
        Heading(stringResource(R.string.settings_about))
        Body(stringResource(R.string.settings_about_body))
        Spacer(Modifier.height(8.dp))
        Heading(stringResource(R.string.settings_privacy))
        Body(stringResource(R.string.settings_privacy_body))
        Spacer(Modifier.height(8.dp))
        Body(stringResource(R.string.settings_support, stringResource(R.string.support_email)))
        Body(stringResource(R.string.settings_version, BuildConfig.VERSION_NAME))
    }
}

@Composable
private fun Heading(text: String) = Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))

@Composable
private fun Body(text: String) =
    Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun Divider() = HorizontalDivider(Modifier.padding(vertical = 12.dp))

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
