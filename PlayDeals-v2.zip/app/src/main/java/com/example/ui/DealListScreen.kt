package com.example.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.Category
import com.example.data.Deal
import com.example.domain.DealFilters
import com.example.domain.PriceRange
import com.example.domain.SortOption
import com.example.util.Times

@Composable
fun sortLabel(s: SortOption): String = stringResource(
    when (s) {
        SortOption.NEWEST -> R.string.sort_newest
        SortOption.BIGGEST_DISCOUNT -> R.string.sort_biggest_discount
        SortOption.ENDING_SOON -> R.string.sort_ending_soon
        SortOption.LOWEST_PRICE -> R.string.sort_lowest_price
    }
)

@Composable
fun priceLabel(p: PriceRange): String = stringResource(
    when (p) {
        PriceRange.ANY -> R.string.price_any
        PriceRange.UNDER_1 -> R.string.price_under_1
        PriceRange.FROM_1_TO_5 -> R.string.price_1_to_5
        PriceRange.OVER_5 -> R.string.price_over_5
    }
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DealListScreen(
    isDiscountTab: Boolean,
    feed: FeedUiState,
    deals: List<Deal>,
    controls: Controls,
    isFavorite: (Deal) -> Boolean,
    onCategory: (Category?) -> Unit,
    onSort: (SortOption) -> Unit,
    onPriceRange: (PriceRange) -> Unit,
    onOpen: (Deal) -> Unit,
    onToggleFavorite: (Deal) -> Unit,
    onRetry: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf(null, Category.APPS, Category.GAMES, Category.WATCH_FACES).forEach { c ->
                FilterChip(selected = controls.category == c, onClick = { onCategory(c) }, label = { Text(categoryLabel(c)) })
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(R.string.deal_count, deals.size),
                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 8.dp).weight(1f),
            )
            if (isDiscountTab) {
                Menu(
                    label = priceLabel(controls.priceRange), icon = { Icon(Icons.Filled.Sell, null) },
                    options = PriceRange.values().toList(), optionLabel = { priceLabel(it) }, onPick = onPriceRange,
                )
            }
            val sorts = SortOption.values().filter {
                (it != SortOption.ENDING_SOON || DealFilters.canSortByEnding(feed.deals)) &&
                    (it != SortOption.BIGGEST_DISCOUNT || isDiscountTab)
            }
            Menu(
                label = sortLabel(controls.sort), icon = { Icon(Icons.AutoMirrored.Filled.Sort, null) },
                options = sorts, optionLabel = { sortLabel(it) }, onPick = onSort,
            )
        }

        val now = System.currentTimeMillis() / 1000
        if (feed.fromCache && feed.deals.isNotEmpty()) Banner(stringResource(R.string.offline_banner))
        else if (feed.generatedAt > 0 && now - feed.generatedAt > 6 * 3600) {
            Banner(stringResource(R.string.stale_banner, Times.relative(feed.generatedAt)))
        }

        when {
            feed.loading -> LazyColumn(
                contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
            ) { items(6) { SkeletonCard() } }

            feed.deals.isEmpty() && feed.error != null -> MessageState(
                Icons.Filled.CloudOff, stringResource(R.string.error_title),
                stringResource(R.string.error_body, feed.error), stringResource(R.string.action_retry), onRetry,
            )

            deals.isEmpty() -> {
                val filtered = controls.category != null || controls.query.isNotBlank() || controls.priceRange != PriceRange.ANY
                MessageState(
                    Icons.Filled.SearchOff,
                    stringResource(
                        when {
                            filtered -> R.string.empty_filtered
                            isDiscountTab -> R.string.empty_discount
                            else -> R.string.empty_free
                        }
                    ),
                    stringResource(if (filtered) R.string.empty_filtered_body else R.string.empty_body),
                )
            }

            else -> LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(deals, key = { it.eventId }) { deal ->
                    DealCard(deal, isFavorite(deal), onClick = { onOpen(deal) }, onToggleFavorite = { onToggleFavorite(deal) })
                }
            }
        }
    }
}

@Composable
private fun <T> Menu(
    label: String,
    icon: @Composable () -> Unit,
    options: List<T>,
    optionLabel: @Composable (T) -> String,
    onPick: (T) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }) {
            icon()
            Spacer(Modifier.width(6.dp))
            Text(label)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option ->
                DropdownMenuItem(text = { Text(optionLabel(option)) }, onClick = { onPick(option); open = false })
            }
        }
    }
}
