package com.example.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.MainActivity
import com.example.R
import com.example.data.Deal
import com.example.data.DealRepository
import com.example.data.DealType
import com.example.data.Prefs
import com.example.data.categoryEnum
import com.example.data.type
import java.util.concurrent.TimeUnit

/**
 * Checks the feed every few hours in the background and posts ONE summary
 * notification for deal events the user hasn't seen. A deal is identified by
 * its event id, so a source re-posting the same offer never notifies twice.
 */
class DealCheckWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val prefs = Prefs(applicationContext)
        if (!prefs.notifyFree && !prefs.notifyDiscount) return Result.success()
        val firstRun = !prefs.hasKnownEvents
        val known = prefs.knownEventIds
        val repo = DealRepository(applicationContext, prefs)
        val result = repo.load(prefs.country)
        if (result.fromCache) return Result.retry()

        val fresh = DealNotifier.selectNew(result.deals, known, prefs.notifyFree, prefs.notifyDiscount, prefs.notifyCategories)
        repo.markSeen(result.deals)
        if (!firstRun && fresh.isNotEmpty()) DealNotifier.post(applicationContext, fresh)
        return Result.success()
    }
}

object DealNotifier {
    private const val CHANNEL_ID = "new_deals"
    private const val WORK_NAME = "deal_check"
    private const val NOTIFICATION_ID = 1001

    fun selectNew(
        deals: List<Deal>, known: Set<String>, free: Boolean, discount: Boolean, categories: Set<String>,
    ): List<Deal> = deals.filter { d ->
        d.eventId !in known &&
            ((d.type == DealType.FREE && free) || (d.type == DealType.DISCOUNT && discount)) &&
            (categories.isEmpty() || d.categoryEnum.name in categories)
    }

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, context.getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = context.getString(R.string.notif_channel_desc) }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun canPost(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun post(context: Context, deals: List<Deal>) {
        if (!canPost(context)) return
        ensureChannel(context)
        val freeCount = deals.count { it.type == DealType.FREE }
        val title = when {
            freeCount == deals.size -> context.getString(R.string.notif_title_free, deals.size)
            freeCount == 0 -> context.getString(R.string.notif_title_discount, deals.size)
            else -> context.getString(R.string.notif_title_mixed, deals.size)
        }
        val text = deals.take(5).joinToString(", ") { it.title }
        val intent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pending = PendingIntent.getActivity(
            context, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_deal)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
            // Permission was revoked between the check and the post; nothing to do.
        }
    }

    /** Starts or stops the background check to match the user's settings. */
    fun sync(context: Context, prefs: Prefs) {
        val wm = WorkManager.getInstance(context)
        if (prefs.notifyFree || prefs.notifyDiscount) {
            val request = PeriodicWorkRequestBuilder<DealCheckWorker>(4, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            wm.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        } else {
            wm.cancelUniqueWork(WORK_NAME)
        }
    }
}
