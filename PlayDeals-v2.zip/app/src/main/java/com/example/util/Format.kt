package com.example.util

import java.math.BigDecimal
import java.text.NumberFormat
import java.util.Currency
import java.util.Locale

object Format {
    /** Formats Play's integer micros in the deal's own currency. No conversion, ever. */
    fun price(micros: Long, currencyCode: String?, locale: Locale = Locale.getDefault()): String {
        val amount = BigDecimal.valueOf(micros).movePointLeft(6)
        val fmt = NumberFormat.getCurrencyInstance(locale)
        val currency = currencyCode?.let { runCatching { Currency.getInstance(it) }.getOrNull() }
        return if (currency != null) {
            fmt.currency = currency
            fmt.maximumFractionDigits = currency.defaultFractionDigits.coerceAtLeast(0)
            fmt.minimumFractionDigits = fmt.maximumFractionDigits
            fmt.format(amount)
        } else {
            amount.setScale(2, java.math.RoundingMode.HALF_UP).toPlainString() + (currencyCode?.let { " $it" } ?: "")
        }
    }

    fun countryName(code: String, locale: Locale = Locale.getDefault()): String {
        val name = Locale("", code.uppercase()).getDisplayCountry(locale)
        return if (name.isBlank() || name.equals(code, ignoreCase = true)) code.uppercase() else name
    }
}
