package com.example

import com.example.data.Category
import com.example.data.Deal
import com.example.data.DealType
import com.example.data.FeedClient
import com.example.data.isExpired
import com.example.domain.DealFilter
import com.example.domain.DealFilters
import com.example.domain.PriceRange
import com.example.domain.SortOption
import com.example.notify.DealNotifier
import com.example.util.Format
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

class DealLogicTest {
    private fun deal(
        id: String, type: String = "FREE", cat: String = "APPS", price: Long = 0, orig: Long = 1_990_000,
        pct: Int? = 100, started: Long = 100, expires: Long? = null, title: String = id,
    ) = Deal(
        eventId = "e_$id", packageId = "com.t.$id", title = title, developer = "Dev $id", category = cat,
        dealType = type, priceMicros = price, originalPriceMicros = orig, currency = "USD", discountPercent = pct,
        country = "US", verifiedAt = started, dealStartedAt = started, expiresAt = expires,
        playUrl = "https://play.google.com/store/apps/details?id=com.t.$id",
    )

    private val all = listOf(
        deal("a", started = 300),
        deal("b", type = "DISCOUNT", cat = "GAMES", price = 990_000, orig = 4_990_000, pct = 80, started = 200, expires = 5_000),
        deal("c", type = "DISCOUNT", cat = "WATCH_FACES", price = 6_000_000, orig = 9_000_000, pct = 33, started = 100),
        deal("d", cat = "GAMES", started = 50, title = "Monument Valley"),
    )

    @Test fun filtersByType() {
        assertEquals(listOf("a", "d"), DealFilters.apply(all, DealFilter(type = DealType.FREE)).map { it.packageId.removePrefix("com.t.") })
        assertEquals(2, DealFilters.apply(all, DealFilter(type = DealType.DISCOUNT)).size)
    }

    @Test fun filtersByCategory() {
        assertEquals(listOf("com.t.c"), DealFilters.apply(all, DealFilter(category = Category.WATCH_FACES)).map { it.packageId })
    }

    @Test fun searchMatchesTitleDeveloperAndPackage() {
        assertEquals(listOf("com.t.d"), DealFilters.apply(all, DealFilter(query = "monument")).map { it.packageId })
        assertEquals(listOf("com.t.b"), DealFilters.apply(all, DealFilter(query = "dev b")).map { it.packageId })
    }

    @Test fun sortsByDiscountAndEnding() {
        val byPct = DealFilters.apply(all.filter { it.dealType == "DISCOUNT" }, DealFilter(sort = SortOption.BIGGEST_DISCOUNT))
        assertEquals(listOf("com.t.b", "com.t.c"), byPct.map { it.packageId })
        val ending = DealFilters.apply(all, DealFilter(sort = SortOption.ENDING_SOON))
        assertEquals("com.t.b", ending.first().packageId)
    }

    @Test fun endingSoonOnlyWhenExpiryKnown() {
        assertTrue(DealFilters.canSortByEnding(all))
        assertFalse(DealFilters.canSortByEnding(all.map { it.copy(expiresAt = null) }))
    }

    @Test fun priceRange() {
        assertEquals(listOf("com.t.c"), DealFilters.apply(all, DealFilter(type = DealType.DISCOUNT, priceRange = PriceRange.OVER_5)).map { it.packageId })
        assertEquals(listOf("com.t.b"), DealFilters.apply(all, DealFilter(type = DealType.DISCOUNT, priceRange = PriceRange.UNDER_1)).map { it.packageId })
    }

    @Test fun expiry() {
        assertTrue(deal("x", expires = 10).isExpired(11))
        assertFalse(deal("x", expires = null).isExpired(Long.MAX_VALUE))
    }

    @Test fun notificationsOnlyForNewMatchingEvents() {
        val fresh = DealNotifier.selectNew(all, setOf("e_a"), free = true, discount = false, categories = setOf("GAMES"))
        assertEquals(listOf("com.t.d"), fresh.map { it.packageId })
        assertTrue(DealNotifier.selectNew(all, all.map { it.eventId }.toSet(), true, true, emptySet()).isEmpty())
    }

    @Test fun priceFormattingUsesDealCurrency() {
        assertEquals("$4.99", Format.price(4_990_000, "USD", Locale.US))
        assertEquals("1.99 XYZ", Format.price(1_990_000, "XYZ", Locale.US))
    }

    @Test fun parsesFeedJson() {
        val json = """{"schema_version":1,"generated_at":5,"country":"US","deals":[{"event_id":"e1","package_id":"com.a.b",
            "title":"T","developer":null,"icon_url":null,"category":"GAMES","deal_type":"FREE","price_micros":0,
            "original_price_micros":2990000,"currency":"USD","discount_percent":100,"country":"US","verified_at":4,
            "deal_started_at":3,"expires_at":null,"price_evidence":"play_strikethrough","has_iap":true,
            "play_url":"https://play.google.com/store/apps/details?id=com.a.b","future_field":"ignored"}]}"""
        val file = FeedClient.parseDeals(json)
        assertEquals(1, file.deals.size)
        assertEquals(2_990_000L, file.deals[0].originalPriceMicros)
        assertTrue(file.deals[0].hasIap)
    }
}
