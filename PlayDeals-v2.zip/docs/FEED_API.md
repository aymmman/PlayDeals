# Feed API (what the app downloads)

Base URL: `https://raw.githubusercontent.com/<owner>/<repo>/deals-data/`

## index.json
```json
{"schema_version": 1, "generated_at": 1792227338,
 "countries": [{"code": "US", "count": 42, "file": "deals_us.json"}]}
```

## deals_<country>.json
```json
{"schema_version": 1, "generated_at": 1792227338, "country": "US", "deals": [ DEAL, ... ]}
```

DEAL fields:

| Field | Type | Meaning |
|---|---|---|
| event_id | string | Unique per promotion. Changes when a product goes on sale again |
| package_id | string | Google Play package ID |
| title, developer, icon_url | string / null | From the Play listing |
| category | `APPS` \| `GAMES` \| `WATCH_FACES` | From Play genre |
| deal_type | `FREE` \| `DISCOUNT` | User-facing category |
| price_micros | int | Current price, 1,000,000 = 1 unit of currency |
| original_price_micros | int | Verified previous price |
| currency | string | ISO 4217 code from Play for that country |
| discount_percent | int | Rounded down; 100 for free |
| country | string | Store country |
| verified_at | int | Unix seconds of the last successful Play check |
| deal_started_at | int / null | When we first verified this promotion |
| expires_at | int / null | Only when Google Play states an end time |
| price_evidence | `play_strikethrough` \| `observed_price_history` | Where the previous price came from |
| has_iap | bool | Listing mentions in-app purchases |
| play_url | string | Canonical listing URL |

Times are Unix seconds (UTC). Clients must ignore unknown fields. Deals with `expires_at` in the past
should be hidden even if the file hasn't been regenerated yet. Internal data (sources, evidence, history)
lives only in `state.json` and is never part of this contract. `health.json` is for monitoring only.
