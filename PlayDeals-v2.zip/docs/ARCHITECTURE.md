# Architecture

## The smallest thing that works

```
 GitHub Actions (every 2 h)                         Android app
 ┌──────────────────────────────────────────┐       ┌──────────────────────────┐
 │ connectors ─> merge/dedupe ─> Play check │       │ downloads index.json and │
 │ ─> classify ─> publish JSON ─> push to   │──────>│ deals_<country>.json,    │
 │ the deals-data branch                    │ HTTPS │ caches them, filters,    │
 └──────────────────────────────────────────┘ (raw) │ favourites, notifications│
                                                    └──────────────────────────┘
```

* **Backend**: Python 3.12, standard library only (`backend/playdeals`). Runs on GitHub's servers, so data
  keeps flowing when nobody has the app open.
* **Storage**: `state.json` on the `deals-data` branch, force-pushed as a single commit each run so the repo
  never grows. Holds only products a source mentioned, never the Play catalogue.
* **Delivery**: static JSON over `raw.githubusercontent.com`. No server, no API keys in the APK, no cost.
  Requires the repository to be **public** (a private repo's files can't be read without a token).
* **App**: Kotlin, Jetpack Compose, MVVM (one ViewModel), OkHttp + Moshi, WorkManager for notifications,
  SharedPreferences for favourites and settings. Room, Retrofit, Firebase and Gemini were removed: nothing
  needed them.

### Why not Supabase/PostgreSQL yet

| | JSON on a git branch (now) | Supabase Postgres (later) |
|---|---|---|
| Cost | $0 | $0 free tier, $25/month Pro |
| Setup for you | none | account, keys as GitHub secrets |
| Good up to | a few thousand records, 1 to 5 countries | far beyond |
| Server-side search/paging | no (app filters locally) | yes |
| Push notifications via FCM | no (app polls every 4 h) | possible with an Edge Function |

Switch when the feed passes about 1 MB per country, you add more than ~5 countries, or you want instant push.
`backend/schema.sql` is the ready target schema with indexes and uniqueness constraints.

## Verification rules (backend/playdeals/verify.py)

States: DISCOVERED, PENDING_VERIFICATION, VERIFIED_FREE, VERIFIED_DISCOUNT, EXPIRED, REJECTED,
VERIFICATION_FAILED, NEEDS_RECHECK. Users only ever see FREE or DISCOUNT.

1. Fetch the listing for the configured country (`gl=US` by default).
2. Read the current price from the embedded data, cross-checked against the page's schema.org JSON-LD.
   If they disagree, the check fails. A guessed price is never published.
3. Previous price evidence, in order:
   * Google Play's own struck-through regular price (`play_strikethrough`), or
   * a higher paid price we observed for the same product, country and currency within 14 days
     (`observed_price_history`).
4. Price 0 with evidence: VERIFIED_FREE. Lower price with at least 10% off (rounded down): VERIFIED_DISCOUNT.
   Free with no paid history: REJECTED (never shown as "newly free"). Normal price: REJECTED, or EXPIRED if it
   was live.
5. Network or parsing errors on a live deal: NEEDS_RECHECK. It stays visible for at most 12 hours after the
   last successful check (the card always shows when it was last checked), then disappears.
6. HTTP 404 for a country: not available there, so REJECTED/EXPIRED for that country only.
7. "Ending soon" and end dates only appear when Google Play itself provided an end time.

Re-check schedule: live deals every run; new leads immediately; failed checks after 2 h; known paid products
once a day (this is how repeat sales are caught); always-free products once a week. Records nobody has
mentioned for 30 days are deleted.

## Deduplication

The identity of a product is its **package ID**, extracted from any Play URL form (`details?id=`,
`market://`, extra parameters, escaped `&amp;`). The record key is `package_id|country`, so different
country prices are never merged. Every source that mentions a product is attached to that one record as
internal evidence; the published feed has one item per product per country. A new promotion after an
expiry gets a new `event_id`, which is what notifications are keyed on, so re-posts never notify twice.
Titles are never used for matching.

Watch faces: Wear OS faces on Google Play also have package IDs, so the same rule applies. Category comes from
Play's genre (`GAME_*`, `WATCH_FACE`), with a title check for faces filed under other genres.

## Monthly cost estimates

| Scale | Assumptions | Cost |
|---|---|---|
| MVP (now) | Public repo, 1 country, ~100 to 400 products, run every 2 h (~3 min) | **$0** (public repos get free Actions minutes) |
| Moderate | 3 to 5 countries, ~2,000 checks/run, Supabase Free, FCM push | **$0 to $25** (Supabase Pro if you exceed free limits) |
| Larger | 20 countries, hourly, dedicated worker (e.g. Fly.io/Render), Supabase Pro, proxy budget if Play rate-limits | **$50 to $150** |

A private repo would use about 1,100 Actions minutes/month at MVP scale, inside the 2,000 free minutes, but
the app couldn't read the feed (see above).

## Known limitations

* Google Play's page format is undocumented and can change. `check_health.py` fails the workflow (GitHub emails
  you) when no listing can be read. Fix point: `backend/playdeals/play_store.py`.
* Reading Play listings automatically is a grey area under Google's terms. We keep volume low (1.5 s between
  requests, at most 250 per run), identify ourselves in the User-Agent and never bypass blocks.
* Only the upfront price is verified. In-app purchases and subscriptions are flagged, not priced.
* Discovery is thin until Reddit API access or a partner feed is added; the watchlist keeps known paid apps
  under daily watch meanwhile.
* GitHub turns off scheduled workflows after 60 days without repository activity. Re-enable from the Actions tab
  if that happens.
* Notifications come from a 4-hourly background check, not instant push. Android may delay it further on
  battery saver.

## Roadmap

1. Apply for Reddit API access (non-commercial while free) and add the three secrets.
2. Email WearOS Faces and AppBrain asking for a feed or permission; enable their registry entries when granted.
3. Add a developer submission form (e.g. a Google Form) that feeds the watchlist.
4. Add countries in `backend/config.json` (each one multiplies Play requests).
5. Move to Supabase + FCM when the limits above are reached.
6. Arabic translation: add `res/values-ar/strings.xml`. Layouts already use start/end and mirrored icons.
