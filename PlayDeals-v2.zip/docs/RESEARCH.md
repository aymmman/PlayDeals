# Source research (17 October 2026)

How this was done: the five sources named in the master prompt were inspected first (websites, terms pages,
GitHub repositories), then web searches looked for more deal publishers, feeds and APIs.

Coverage: 11 candidate sources found, 11 evaluated, 2 usable today (Google Play itself as the price
authority, and our own curated watchlist), 1 usable once you obtain credentials (Reddit OAuth API).
This is not "every website on the internet". Gaps: regional (non-English) deal sites, Telegram/Discord deal
channels and developer mailing lists were not surveyed.

Legend: VERIFIED = seen directly on the live page or repo. DOCS = stated in the source's own terms or
documentation. SECONDARY = reported by third-party articles, not confirmed first-hand. UNCONFIRMED = not checked.

## Inventory

| # | Source | Pages inspected | What it offers | Programmatic access | Terms / permission | Decision |
|---|---|---|---|---|---|---|
| 1 | **Google Play listing** | play.google.com/store/apps/details?id=... | Current price, struck-through regular price during sales, currency per country, sometimes sale end time | No official public consumer-price API. Listing page embeds data in `AF_initDataCallback` blocks (VERIFIED via the code of two independent projects that parse it) | Automated access to Google services is restricted by Google's terms; we make low-volume, rate-limited reads of individual public listings, the same method used by Play Deals and google-play-scraper. Risk documented in ARCHITECTURE.md | **Used as the verification authority** |
| 2 | **Curated watchlist** (ours) | backend/manual_watchlist.txt | Package IDs you add (developer submissions, tips, known paid apps) | File in the repo | Our own data | **Enabled** |
| 3 | **Reddit r/googleplaydeals** | reddit.com/r/googleplaydeals, redditinc.com/policies/data-api-terms | Community posts with Play links, apps, games, watch faces | Official OAuth Data API (DOCS). robots.txt disallows all crawling since July 2024 (SECONDARY: Search Engine Land, TechCrunch). Unauthenticated .json reportedly returns 403 since May 2026 (SECONDARY) | Free tier is non-commercial only; commercial use needs a Reddit agreement, 2 to 4 week manual approval (SECONDARY) | **Connector built, dormant until REDDIT_CLIENT_ID/SECRET are set** |
| 4 | **WearOS Faces** | wearosfaces.com, /terms | 149 active watch-face deals and 38 coupons on 17 Oct (VERIFIED), developer sale reports | No public feed or API found | Terms prohibit automated scraping or bulk access (DOCS) | **Disabled. Ask the owner for a partner feed** |
| 5 | **AppBrain deals** | appbrain.com/deals | ~100 deals (31 free, 69 discounted on 17 Oct), schema.org ItemList with prices and priceValidUntil (VERIFIED) | Deals page is public; AppBrain sells a paid Intelligence API (VERIFIED) | Reuse terms not found; commercial data company | **Disabled pending permission** |
| 6 | **AppAgg** | appagg.com/deals/ | Multi-platform deals, claims RSS feeds (SECONDARY) | Page returns a JavaScript bot check (VERIFIED). No documented feed URL found | Bypassing anti-bot checks is not allowed | **Blocked** |
| 7 | **AppSales** (net.tsapps.appsales) | Play listing, app-sales.net search result | Active sales list incl. watch faces (search snippet) | No documented public API; activesales page returned 404 to our fetcher | Terms not found | **Not integrated. Contact the developer** |
| 8 | **Play Deals** (psuzn) | github.com/psuzn/play-deals, github.com/psuzn/Play-Deals-Backend | Android app + Kotlin backend; Reddit `new.json` + Play page parsing (VERIFIED in code) | Code only; no public API we can rely on | GPL-3.0 (VERIFIED). Last commit Aug 2024 (VERIFIED) | **Approach reused, no code copied** (GPL would force our app to be GPL) |
| 9 | **google-play-scraper** (Python) | PyPI 1.2.7 | Parser for Play listing fields incl. price, originalPrice, sale | Library | MIT (VERIFIED) | Field paths cross-checked; own implementation written |
| 10 | **9to5Toys daily Google Play deals** | 9to5toys.com Android deals posts | Daily roundups with direct Play links (VERIFIED) | WordPress site; feed URL not verified, so not used | Editorial site with affiliate links; terms not reviewed | **Used once by hand** to seed the watchlist (package IDs are facts; no text copied). Not automated |
| 11 | **Android Police / 9to5Google style weekly sale posts** | not inspected | Weekly lists | UNCONFIRMED | UNCONFIRMED | Roadmap |

## Why the original app's sources were wrong

The AI Studio version claimed to use `reddit.com/r/googleplaydeals/new.json`, an "AppAgg RSS/HTML" connector
rate limited at 60 req/hr, a "WearOS Faces WatchFace API" and a "Play Store DOM & Schema Engine". None of these
were implemented, the AppAgg rate limit and WearOS Faces API were invented, and the Reddit JSON route is no
longer compliant.

## How to add a source

1. Confirm permission (terms page, email from the owner, or a paid API agreement). Save the evidence.
2. Add an entry to `backend/sources.json`. Use `rss_play_links` for any feed that contains Play links,
   or write a new connector in `backend/playdeals/connectors/` that returns `Candidate` objects.
3. Run `cd backend && python -m pytest -q`, commit, and watch the next "Update deals" run.

Every source only *suggests* products. Google Play decides what gets published.
