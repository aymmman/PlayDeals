# v3 (17 October 2026)
* Developer expansion: when any app has a live deal, the developer's other apps are found and verified,
  in the same run when budget allows.
* Self-growing watchlist: paid apps are remembered for 180 days and rechecked daily.
* Health check now reports developer pages read, new apps found and the waiting backlog.
* Update deals workflow uses newer GitHub action versions (removes the Node.js 20 warning).

# What changed from the AI Studio version

## Removed (fake or forbidden by the brief)
* All hardcoded deals, prices, "evidence", ratings, review counts and download numbers.
* The "Recheck" button that only appended a fake evidence line.
* The "Sources" tab that exposed internal feed URLs to users.
* Currency conversion with made-up exchange rates (prices now show in the store's own currency).
* "Ending soon" timers with invented end dates, and the "Top rated" sort.
* Unused Firebase, Gemini, App Check, Room, Retrofit, KSP and Secrets plugins.

## Added
* `backend/`: real pipeline. Connectors (watchlist, Reddit OAuth API, generic RSS), dedupe by package ID and
  country, live Google Play verification, classification, expiry, retries, retention, JSON feed, health check.
* App: Free / Discounts / Saved / Settings tabs, category chips, search, sort, price range, detail sheet with
  verification time and evidence, open in Play, share, offline cache, loading skeletons, empty and error states,
  favourites that show "Ended" when a deal finishes, store region picker, optional notifications for new deals.
* GitHub workflows for the APK and the 2-hourly deals update.

## Fixed
* Debug build failed on CI because `debug.keystore` was missing; now a shared key lives in `keystore/`.
* Release signing no longer crashes when no upload key is configured.
* Version code increases with every CI build so updates install cleanly.
