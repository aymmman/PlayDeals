# Test report

## Executed (17 October 2026, in the build sandbox)

**Backend: 53 automated tests, all passing** (43 in v2, 10 added in v3 for developer expansion and retention) (`cd backend && python -m pytest -q`)

| Area | Covered cases |
|---|---|
| Sources | valid RSS, valid Atom, empty feed, malformed feed, missing file, connector without credentials, disabled source, Reddit listing parsing, duplicate records |
| Verification | paid to free, paid to discount, always free, expired offer, region-specific price, currency mismatch in history, missing history, incorrect promotional claim, below-threshold discount, failed fetch, 404 in a country, JSON-LD conflict, sale-end sanity |
| Deduplication | same product from several sources, same package via different URLs, repeated publication keeps one event, new promotion gets a new event, country prices kept separate |
| Pipeline | end-to-end free + discount, grace period on network errors then removal, retention cleanup, queue cap with live deals first, feed never contains sources or evidence |

**CLI dry run**: full run against the real watchlist with no network to Google Play. Every check failed
safely as VERIFICATION_FAILED and nothing was published.

**Workflow git logic**: simulated three pipeline runs against a local remote. State carried over between runs
and the data branch stayed at one commit.

**Android pure logic**: models, filters and price formatting compiled with Kotlin 2.2.10 and run successfully.

## Executed on GitHub (v2, 17 October 2026)

* Update deals #1: 95 of 95 Google Play listings read, 73 deals published (US). Run time 2 min 35 s.
* Build APK #3: APK built and Kotlin unit tests passed. App installed and working on the owner's phone.

## Not executed yet (needs GitHub or a phone)

* Live Google Play reads (the sandbox can't reach play.google.com). The first "Update deals" run is the real test;
  its log prints how many listings were read.
* Full Android build and the Kotlin unit tests in `app/src/test` (run automatically by "Build APK").
* On-device checks: install, navigation, search and filters, favourites, detail sheet, Play link, share,
  notification permission and delivery, offline mode (turn on airplane mode after one successful load),
  dark mode, small and large screens.
* Arabic/RTL: not applicable until a translation is added.
