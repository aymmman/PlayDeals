import json

from helpers import NOW, FakePlay, make_page
from playdeals.pipeline import Config, run, retention
from playdeals.play_store import parse_developer_apps, parse_developer_url, parse_listing
from playdeals.state import State

DEV = "/store/apps/dev?id=111"


def setup(tmp_path, watch="com.cat.hybrid\n"):
    (tmp_path / "manual.txt").write_text(watch)
    return [{"id": "manual", "connector_type": "manual_watchlist", "path": "manual.txt", "enabled": True}]


def go(tmp_path, sources, pages, dev_pages, now, **cfg):
    fake = FakePlay(pages, dev_pages)
    summary = run(str(tmp_path / "state.json"), str(tmp_path), sources, str(tmp_path),
                  Config(countries=["us"], **cfg), fake, now)
    feed = json.loads((tmp_path / "deals_us.json").read_text())["deals"]
    return summary, {d["package_id"] for d in feed}, fake


def test_listing_exposes_developer_path():
    s = parse_listing(make_page(current=0, original=1, dev_path=DEV), "a.b", "us", "u", NOW)
    assert s.developer_url == DEV
    assert parse_developer_url('<a href="/store/apps/developer?id=Cat+Lab&amp;hl=en">') == "/store/apps/developer?id=Cat+Lab"


def test_developer_path_from_embedded_data_fallback():
    s = parse_listing(make_page(current=0, original=1, dev_path_embedded="/store/apps/dev?id=999"), "a.b", "us", "u", NOW)
    assert s.developer_url == "/store/apps/dev?id=999"


def test_developer_page_parsing_dedupes():
    page = ('<a href="/store/apps/details?id=com.cat.a"></a><a href="/store/apps/details?id=com.cat.a&hl=en">'
            '<a href="/store/apps/details?id=com.cat.b"></a><a href="/store/apps/details?id=bad">')
    assert parse_developer_apps(page) == ["com.cat.a", "com.cat.b"]


def test_live_deal_pulls_in_the_rest_of_the_catalogue_same_run(tmp_path):
    sources = setup(tmp_path)
    pages = {("com.cat.hybrid", "us"): make_page(current=0, original=1_990_000, dev_path=DEV),
             ("com.cat.cooking", "us"): make_page(title="Cooking Quest VIP", current=0, original=1_490_000, dev_path=DEV),
             ("com.cat.paid", "us"): make_page(current=2_990_000, dev_path=DEV),
             ("com.cat.free", "us"): make_page(current=0, dev_path=DEV)}
    summary, published, fake = go(tmp_path, sources, pages, {DEV: ["com.cat.hybrid", "com.cat.cooking", "com.cat.paid", "com.cat.free"]}, NOW)
    assert published == {"com.cat.hybrid", "com.cat.cooking"}
    assert summary["developer_expansion"] == {"pages_read": 1, "new_candidates": 3, "errors": 0}
    state = State.load(str(tmp_path / "state.json"))
    sources_of_cooking = {s.source_id for s in state.records["com.cat.cooking|us"].sources}
    assert sources_of_cooking == {"developer_expansion"}


def test_developer_page_not_reread_within_cooldown(tmp_path):
    sources = setup(tmp_path)
    pages = {("com.cat.hybrid", "us"): make_page(current=0, original=1_990_000, dev_path=DEV)}
    _, _, f1 = go(tmp_path, sources, pages, {DEV: []}, NOW)
    _, _, f2 = go(tmp_path, sources, pages, {DEV: []}, NOW + 2 * 86400)
    _, _, f3 = go(tmp_path, sources, pages, {DEV: []}, NOW + 4 * 86400)
    assert (len(f1.dev_requests), len(f2.dev_requests), len(f3.dev_requests)) == (1, 0, 1)


def test_caps_on_pages_and_apps(tmp_path):
    sources = setup(tmp_path, "com.d1.x\ncom.d2.x\ncom.d3.x\n")
    pages = {(f"com.d{i}.x", "us"): make_page(current=0, original=1_000_000, dev_path=f"/store/apps/dev?id={i}")
             for i in (1, 2, 3)}
    dev_pages = {f"/store/apps/dev?id={i}": [f"com.d{i}.app{j}" for j in range(10)] for i in (1, 2, 3)}
    summary, _, fake = go(tmp_path, sources, pages, dev_pages, NOW, max_dev_pages_per_run=2, max_apps_per_developer=4)
    assert summary["developer_expansion"]["pages_read"] == 2
    assert summary["developer_expansion"]["new_candidates"] == 8


def test_expansion_error_is_recorded_not_fatal(tmp_path):
    sources = setup(tmp_path)
    pages = {("com.cat.hybrid", "us"): make_page(current=0, original=1_990_000, dev_path=DEV)}
    summary, published, _ = go(tmp_path, sources, pages, {}, NOW)  # dev page errors
    assert published == {"com.cat.hybrid"} and summary["developer_expansion"]["errors"] == 1
    assert State.load(str(tmp_path / "state.json")).developers[DEV]["error"] == "http_500"


def test_no_expansion_without_live_deals(tmp_path):
    sources = setup(tmp_path)
    pages = {("com.cat.hybrid", "us"): make_page(current=1_990_000, dev_path=DEV)}
    _, _, fake = go(tmp_path, sources, pages, {DEV: ["com.cat.other"]}, NOW)
    assert fake.dev_requests == []


def test_check_budget_shared_with_second_pass(tmp_path):
    sources = setup(tmp_path)
    pages = {("com.cat.hybrid", "us"): make_page(current=0, original=1_990_000, dev_path=DEV)}
    summary, _, _ = go(tmp_path, sources, pages, {DEV: [f"com.cat.a{j}" for j in range(30)]}, NOW,
                       max_checks_per_run=10, max_apps_per_developer=40)
    assert summary["checked"] == 10 and summary["backlog_unchecked"] == 21


def test_paid_apps_outlive_free_ones_in_retention():
    from playdeals.models import DealRecord
    st = State({
        "paid|us": DealRecord("com.p.paid", "us", last_source_seen=NOW - 60 * 86400,
                              price_history=[{"at": NOW, "price": 1_000_000, "currency": "USD"}]),
        "free|us": DealRecord("com.p.free", "us", last_source_seen=NOW - 60 * 86400,
                              price_history=[{"at": NOW, "price": 0, "currency": "USD"}]),
    })
    retention(st, Config(countries=["us"]), NOW)
    assert list(st.records) == ["paid|us"]
