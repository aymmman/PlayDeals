"""Ingestion -> Normalization -> Identity -> Dedup -> Verification ->
Classification -> Publication. One run is idempotent and safe to repeat."""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Optional, Protocol

from .connectors import build_connector
from .models import VERIFIED_STATES, Candidate, DealRecord, PlaySnapshot, SourceRef, Status
from .normalize import canonical_play_url
from .state import State, write_json_atomic
from .verify import category_for, classify

log = logging.getLogger("playdeals")

FEED_SCHEMA_VERSION = 1
MAX_EVIDENCE = 10
MAX_PRICE_POINTS = 30
MAX_SOURCES_PER_RECORD = 20


class PlayFetcher(Protocol):
    requests_made: int

    def fetch(self, package_id: str, country: str) -> PlaySnapshot: ...


@dataclass
class Config:
    countries: list[str]
    min_discount_percent: int = 10
    max_checks_per_run: int = 250
    grace_hours: int = 12
    watch_recheck_hours: int = 24
    free_recheck_days: int = 7
    failed_retry_minutes: int = 120
    fresh_check_minutes: int = 60
    retention_days: int = 30
    paid_retention_days: int = 180
    dev_expand_days: int = 3
    max_dev_pages_per_run: int = 40
    max_apps_per_developer: int = 40

    @classmethod
    def from_dict(cls, d: dict) -> "Config":
        allowed = cls.__dataclass_fields__.keys()
        cfg = cls(**{k: v for k, v in d.items() if k in allowed})
        cfg.countries = [c.lower() for c in cfg.countries]
        return cfg


# --------------------------------------------------------------------------- ingest

def ingest(state: State, sources: list[dict], base_dir: str, cfg: Config, now: int) -> list[Candidate]:
    all_candidates: list[Candidate] = []
    for source in sources:
        sid = source["id"]
        health = state.health.setdefault(sid, {})
        health.update({"name": source.get("name", sid), "enabled": bool(source.get("enabled"))})
        if not source.get("enabled"):
            health.update({"status": "disabled", "note": source.get("permission_status", "")})
            continue
        if source.get("connector_type") == "built_in":
            health.update({"status": "built_in"})
            continue
        try:
            result = build_connector(source, base_dir).collect(now)
        except Exception as e:  # a broken connector must never stop the run
            log.exception("connector %s crashed", sid)
            health.update({"status": "error", "last_error": f"{type(e).__name__}: {e}"[:200], "last_run": now})
            continue
        health["last_run"] = now
        if result.skipped:
            health.update({"status": "skipped", "note": result.skipped})
        elif not result.ok:
            health.update({"status": "error", "last_error": result.error})
        else:
            health.update({"status": "ok", "last_success": now, "last_count": len(result.candidates)})
        all_candidates.extend(result.candidates)
    merge_candidates(state, all_candidates, cfg.countries, now)
    return all_candidates


def merge_candidates(state: State, candidates: list[Candidate], countries: list[str], now: int) -> None:
    """Deduplicate by (package_id, country). Many sources -> one record."""
    for cand in candidates:
        for country in countries:
            key = f"{cand.package_id}|{country}"
            rec = state.records.get(key)
            if rec is None:
                rec = DealRecord(package_id=cand.package_id, country=country, first_seen=now)
                state.records[key] = rec
            rec.last_source_seen = now
            ref = next((s for s in rec.sources if s.source_id == cand.source_id and s.url == cand.source_url), None)
            if ref:
                ref.last_seen = now
            else:
                rec.sources.append(SourceRef(cand.source_id, cand.source_url, cand.seen_at, now))
                rec.sources = sorted(rec.sources, key=lambda s: s.last_seen)[-MAX_SOURCES_PER_RECORD:]


# --------------------------------------------------------------------------- schedule

def is_live(rec: DealRecord) -> bool:
    return rec.live_status is not None


def due_for_check(rec: DealRecord, cfg: Config, now: int) -> Optional[int]:
    """Return a priority (lower = sooner) or None if not due."""
    age = now - rec.last_checked
    if is_live(rec):
        return 0
    if rec.last_checked == 0:
        return 1
    if rec.status in (Status.VERIFICATION_FAILED, Status.DISCOVERED, Status.PENDING_VERIFICATION):
        return 2 if age >= cfg.failed_retry_minutes * 60 else None
    if rec.last_source_seen >= rec.last_checked and age >= cfg.fresh_check_minutes * 60:
        return 2  # a source mentioned it again since our last check
    interval = cfg.free_recheck_days * 86400 if rec.last_reason == "free_without_paid_history" else cfg.watch_recheck_hours * 3600
    return 3 if age >= interval else None


def build_queue(state: State, cfg: Config, now: int) -> list[DealRecord]:
    due = []
    for rec in state.records.values():
        if rec.last_checked == now:
            continue  # already checked in this run
        prio = due_for_check(rec, cfg, now)
        if prio is not None:
            due.append((prio, rec.last_checked, rec.key, rec))
    due.sort(key=lambda t: (t[0], t[1], t[2]))
    queue = [t[3] for t in due[: cfg.max_checks_per_run]]
    for rec in queue:
        if rec.status == Status.DISCOVERED:
            rec.status = Status.PENDING_VERIFICATION
    return queue


# --------------------------------------------------------------------------- verify

def apply_snapshot(rec: DealRecord, snap: PlaySnapshot, cfg: Config, now: int) -> None:
    rec.last_checked = now
    history_before = list(rec.price_history)

    if snap.ok:
        rec.title = snap.title or rec.title or rec.package_id
        rec.developer = snap.developer or rec.developer
        rec.developer_url = snap.developer_url or rec.developer_url
        rec.icon_url = snap.icon_url or rec.icon_url
        rec.genre_id = snap.genre_id or rec.genre_id
        rec.category = category_for(rec.genre_id, rec.title)
        rec.currency = snap.currency or rec.currency
        rec.has_iap = snap.has_iap
        rec.current_price_micros = snap.current_price_micros
        rec.last_success = now
        rec.fail_count = 0
        rec.last_error = None
        _record_price(rec, snap, now)

    verdict = classify(snap, history_before, is_live(rec), cfg.min_discount_percent, now)
    rec.last_reason = verdict.reason
    rec.evidence.append({
        "at": now, "status": verdict.status.value, "method": verdict.method, "reason": verdict.reason,
        "price": snap.current_price_micros, "original": verdict.original_price_micros,
        "currency": snap.currency, "url": snap.url, "http": snap.http_status,
    })
    rec.evidence = rec.evidence[-MAX_EVIDENCE:]

    if verdict.status in VERIFIED_STATES:
        if rec.live_status != verdict.status or rec.event_id is None:
            rec.deal_started_at = now  # a new promotion is a new deal event
            rec.event_id = f"{rec.package_id}|{rec.country}|{verdict.status.value}|{now}"
        rec.status = rec.live_status = verdict.status
        rec.original_price_micros = verdict.original_price_micros
        rec.discount_percent = verdict.discount_percent
        rec.expires_at = snap.sale_ends_at
        rec.verify_method = verdict.method
        return

    if verdict.status == Status.VERIFICATION_FAILED:
        rec.fail_count += 1
        rec.last_error = verdict.reason
        if snap.http_status == 404:
            _end_deal(rec, Status.EXPIRED if is_live(rec) else Status.REJECTED)
            rec.last_reason = "not_available_in_country"
        elif is_live(rec):
            rec.status = Status.NEEDS_RECHECK  # an error is not proof the deal ended
        else:
            rec.status = Status.VERIFICATION_FAILED
        return

    _end_deal(rec, verdict.status)


def _end_deal(rec: DealRecord, status: Status) -> None:
    rec.status = status
    rec.live_status = None
    rec.event_id = None
    rec.deal_started_at = None
    rec.expires_at = None
    rec.original_price_micros = None
    rec.discount_percent = None


def _record_price(rec: DealRecord, snap: PlaySnapshot, now: int) -> None:
    last = rec.price_history[-1] if rec.price_history else None
    changed = not last or last.get("price") != snap.current_price_micros or last.get("currency") != snap.currency
    if changed or now - last.get("at", 0) >= 86400:
        rec.price_history.append({"at": now, "price": snap.current_price_micros, "currency": snap.currency})
        rec.price_history = rec.price_history[-MAX_PRICE_POINTS:]


def verify_queue(queue: list[DealRecord], client: PlayFetcher, cfg: Config, now: int) -> dict[str, int]:
    counts: dict[str, int] = {"_listing_read_ok": 0}
    for rec in queue:
        snap = client.fetch(rec.package_id, rec.country)
        apply_snapshot(rec, snap, cfg, now)
        counts[rec.status.value] = counts.get(rec.status.value, 0) + 1
        if snap.ok:
            counts["_listing_read_ok"] += 1
    return counts


# --------------------------------------------------------------------------- developer expansion

DEV_SOURCE_ID = "developer_expansion"


def expand_developers(state: State, client, cfg: Config, now: int) -> dict:
    """Small developers usually discount their whole catalogue at once. For every
    developer with a live deal, read their Play page (at most every few days) and
    add their other apps as candidates. Verification still decides everything."""
    stats = {"pages_read": 0, "new_candidates": 0, "errors": 0}
    if not hasattr(client, "fetch_developer_apps"):
        return stats
    due: dict[str, DealRecord] = {}
    for rec in sorted(state.records.values(), key=lambda r: -(r.deal_started_at or 0)):
        if not is_live(rec) or not rec.developer_url or rec.developer_url in due:
            continue
        info = state.developers.get(rec.developer_url, {})
        if now - info.get("last_expanded", 0) >= cfg.dev_expand_days * 86400:
            due[rec.developer_url] = rec
    known = {r.package_id for r in state.records.values()}
    for path, rec in list(due.items())[: cfg.max_dev_pages_per_run]:
        ok, packages, error = client.fetch_developer_apps(path, rec.country)
        stats["pages_read"] += 1
        new = [p for p in packages if p not in known][: cfg.max_apps_per_developer]
        state.developers[path] = {"last_expanded": now, "developer": rec.developer, "found": len(packages),
                                  "added": len(new), "error": error}
        if not ok:
            stats["errors"] += 1
            continue
        url = f"https://play.google.com{path}"
        merge_candidates(state, [Candidate(p, DEV_SOURCE_ID, url, now) for p in new], cfg.countries, now)
        known.update(new)
        stats["new_candidates"] += len(new)
    return stats


# --------------------------------------------------------------------------- publish

def was_ever_paid(rec: DealRecord) -> bool:
    return any((p.get("price") or 0) > 0 for p in rec.price_history)


def retention(state: State, cfg: Config, now: int) -> int:
    """Forget products nobody mentions any more. Paid apps are kept much longer:
    they are the watchlist that catches future sales (self-growing watchlist)."""
    stale = []
    for k, r in state.records.items():
        if is_live(r):
            continue
        days = cfg.paid_retention_days if was_ever_paid(r) else cfg.retention_days
        if r.last_source_seen < now - days * 86400:
            stale.append(k)
    for k in stale:
        del state.records[k]
    stale_devs = [d for d, v in state.developers.items() if v.get("last_expanded", 0) < now - cfg.paid_retention_days * 86400]
    for d in stale_devs:
        del state.developers[d]
    return len(stale)


def publishable(rec: DealRecord, cfg: Config, now: int) -> bool:
    if not is_live(rec) or rec.status not in (*VERIFIED_STATES, Status.NEEDS_RECHECK):
        return False
    if now - rec.last_success > cfg.grace_hours * 3600:
        return False  # can't confirm the current price any more
    if rec.expires_at and rec.expires_at < now and rec.status == Status.NEEDS_RECHECK:
        return False
    return rec.current_price_micros is not None and rec.original_price_micros is not None


def feed_item(rec: DealRecord) -> dict:
    return {
        "event_id": rec.event_id,
        "package_id": rec.package_id,
        "title": rec.title or rec.package_id,
        "developer": rec.developer,
        "icon_url": rec.icon_url,
        "category": rec.category.value if rec.category else "APPS",
        "deal_type": "FREE" if rec.live_status == Status.VERIFIED_FREE else "DISCOUNT",
        "price_micros": rec.current_price_micros,
        "original_price_micros": rec.original_price_micros,
        "currency": rec.currency,
        "discount_percent": rec.discount_percent,
        "country": rec.country.upper(),
        "verified_at": rec.last_success,
        "deal_started_at": rec.deal_started_at,
        "expires_at": rec.expires_at,
        "price_evidence": rec.verify_method,
        "has_iap": rec.has_iap,
        "play_url": canonical_play_url(rec.package_id),
    }


def publish(state: State, cfg: Config, out_dir: str, now: int) -> dict[str, int]:
    counts: dict[str, int] = {}
    countries = []
    for country in cfg.countries:
        items = [feed_item(r) for r in state.records.values() if r.country == country and publishable(r, cfg, now)]
        items.sort(key=lambda d: (-(d["deal_started_at"] or 0), d["title"].lower()))
        write_json_atomic(os.path.join(out_dir, f"deals_{country}.json"), {
            "schema_version": FEED_SCHEMA_VERSION, "generated_at": now, "country": country.upper(), "deals": items,
        })
        counts[country] = len(items)
        countries.append({"code": country.upper(), "count": len(items), "file": f"deals_{country}.json"})
    write_json_atomic(os.path.join(out_dir, "index.json"), {
        "schema_version": FEED_SCHEMA_VERSION, "generated_at": now, "countries": countries,
    })
    return counts


def run(state_path: str, out_dir: str, sources: list[dict], base_dir: str, cfg: Config,
        client: PlayFetcher, now: int) -> dict:
    state = State.load(state_path)
    candidates = ingest(state, sources, base_dir, cfg, now)
    queue = build_queue(state, cfg, now)
    checks = verify_queue(queue, client, cfg, now)
    expansion = expand_developers(state, client, cfg, now)
    # Second pass: spend any remaining budget on what expansion just found.
    remaining = cfg.max_checks_per_run - len(queue)
    if expansion["new_candidates"] and remaining > 0:
        second = build_queue(state, Config(**{**cfg.__dict__, "max_checks_per_run": remaining}), now)
        for k, v in verify_queue(second, client, cfg, now).items():
            checks[k] = checks.get(k, 0) + v
        queue += second
    removed = retention(state, cfg, now)
    published = publish(state, cfg, out_dir, now)
    summary = {
        "ran_at": now, "candidates": len(candidates), "records": len(state.records),
        "checked": len(queue), "play_requests": client.requests_made, "results": checks,
        "removed_by_retention": removed, "published": published,
        "developer_expansion": expansion,
        "backlog_unchecked": sum(1 for r in state.records.values() if r.last_checked == 0),
    }
    write_json_atomic(os.path.join(out_dir, "health.json"), {"summary": summary, "sources": state.health})
    state.save(state_path)
    return summary
