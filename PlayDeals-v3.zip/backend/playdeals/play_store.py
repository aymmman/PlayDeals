"""Read the current price of an app from its public Google Play listing.

There is no official public Google Play API that returns consumer prices.
The listing page embeds its data in `AF_initDataCallback` script blocks; the
same approach is used by the MIT-licensed `google-play-scraper` library and by
the GPL-3.0 Play Deals backend (we re-implemented it, no code copied).

The page structure is undocumented and can change without notice, so:
  * every field is looked up in every embedded dataset, not one hardcoded key
  * the current price is cross-checked against the page's schema.org JSON-LD
  * any doubt produces a failed snapshot, never a guessed price
"""
from __future__ import annotations

import html
import json
import re
import time
import urllib.error
import urllib.request
from typing import Any, Callable, Optional

from .models import PlaySnapshot
from .normalize import canonical_play_url, is_valid_package_id

_SCRIPT_RE = re.compile(r"AF_initDataCallback[\s\S]*?</script")
_KEY_RE = re.compile(r"(ds:\d+)'")
_VALUE_RE = re.compile(r"data:([\s\S]*?), sideChannel: \{\}\}\);</")
_JSONLD_RE = re.compile(r'<script type="application/ld\+json"[^>]*>([\s\S]*?)</script>')
# Link from a listing to its developer's page, e.g. /store/apps/dev?id=123 or /store/apps/developer?id=Name
_DEV_LINK_RE = re.compile(r'href="(/store/apps/dev(?:eloper)?\?id=[^"]+)"')
# App links on a developer page are relative.
_APP_LINK_RE = re.compile(r'/store/apps/details\?id=([A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+)')

# Paths inside the app-details dataset (historically ds:5).
P_TITLE = [1, 2, 0, 0]
P_DEVELOPER = [1, 2, 68, 0]
P_ICON = [1, 2, 95, 0, 3, 2]
P_GENRE_ID = [1, 2, 79, 0, 0, 2]
P_PRICE_BLOCK = [1, 2, 57, 0, 0, 0, 0, 1]  # -> [[cur_micros, ccy, text], [orig_micros, ...]?]
P_IAP = [1, 2, 19, 0]
P_DEV_PATH = [1, 2, 68, 1, 4, 2]  # e.g. "/store/apps/dev?id=123"
# Older locations kept as fallbacks.
P_ORIGINAL_ALT = [0, 2, 0, 0, 0, 1, 1, 0]
P_SALE_END_ALT = [0, 2, 0, 0, 0, 14, 0, 0]

USER_AGENT = (
    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/126.0 Mobile Safari/537.36 PlayDealsVerifier/1.0"
)


def _lookup(data: Any, path: list[int]) -> Any:
    cur = data
    for idx in path:
        if not isinstance(cur, list) or idx >= len(cur):
            return None
        cur = cur[idx]
    return cur


def parse_datasets(page: str) -> dict[str, Any]:
    datasets: dict[str, Any] = {}
    for block in _SCRIPT_RE.findall(page):
        key = _KEY_RE.findall(block)
        value = _VALUE_RE.findall(block)
        if key and value:
            try:
                datasets[key[0]] = json.loads(value[0])
            except json.JSONDecodeError:
                continue
    return datasets


def _first(datasets: dict[str, Any], path: list[int], check: Callable[[Any], bool]) -> Any:
    preferred = ["ds:5"] + [k for k in sorted(datasets) if k != "ds:5"]
    for key in preferred:
        if key in datasets:
            value = _lookup(datasets[key], path)
            if value is not None and check(value):
                return value
    return None


def _is_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool) and v >= 0


def _parse_jsonld(page: str) -> tuple[Optional[int], Optional[str]]:
    for raw in _JSONLD_RE.findall(page):
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            continue
        items = data if isinstance(data, list) else [data]
        for item in items:
            if not isinstance(item, dict):
                continue
            offers = item.get("offers")
            offers = offers if isinstance(offers, list) else [offers]
            for offer in offers:
                if isinstance(offer, dict) and "price" in offer:
                    try:
                        micros = round(float(str(offer["price"]).replace(",", "")) * 1_000_000)
                    except ValueError:
                        continue
                    return micros, offer.get("priceCurrency")
    return None, None


def parse_developer_url(page: str) -> Optional[str]:
    match = _DEV_LINK_RE.search(page)
    if not match:
        return None
    path = html.unescape(match.group(1))
    return path.split("&")[0]  # drop hl/gl so one developer has one key


def parse_developer_apps(page: str, limit: int = 200) -> list[str]:
    """Package IDs linked from a developer page, in page order, without duplicates."""
    found: list[str] = []
    for pkg in _APP_LINK_RE.findall(page):
        if is_valid_package_id(pkg) and pkg not in found:
            found.append(pkg)
            if len(found) >= limit:
                break
    return found


def parse_listing(page: str, package_id: str, country: str, url: str, now: int) -> PlaySnapshot:
    """Pure parser, unit-tested with fixture pages."""
    snap = PlaySnapshot(package_id=package_id, country=country, fetched_at=now, url=url, ok=False, http_status=200)
    snap.developer_url = parse_developer_url(page)
    datasets = parse_datasets(page)
    snap.jsonld_price_micros, snap.jsonld_currency = _parse_jsonld(page)

    if not datasets and snap.jsonld_price_micros is None:
        snap.error = "no_embedded_data"
        return snap

    snap.title = _first(datasets, P_TITLE, lambda v: isinstance(v, str) and v.strip() != "")
    snap.developer = _first(datasets, P_DEVELOPER, lambda v: isinstance(v, str))
    snap.icon_url = _first(datasets, P_ICON, lambda v: isinstance(v, str) and v.startswith("http"))
    snap.genre_id = _first(datasets, P_GENRE_ID, lambda v: isinstance(v, str))
    snap.has_iap = bool(_first(datasets, P_IAP, lambda v: isinstance(v, str) and v.strip() != ""))
    if snap.developer_url is None:  # fallback when the HTML link isn't found
        dev = _first(datasets, P_DEV_PATH, lambda v: isinstance(v, str) and "/store/apps/dev" in v)
        if dev:
            snap.developer_url = dev[dev.index("/store/apps/dev"):].split("&")[0]

    block = _first(datasets, P_PRICE_BLOCK, lambda v: isinstance(v, list) and len(v) > 0)
    if block:
        cur = block[0] if isinstance(block[0], list) else None
        if cur and len(cur) >= 2 and _is_int(cur[0]):
            snap.current_price_micros = cur[0]
            snap.currency = cur[1] if isinstance(cur[1], str) else None
        if len(block) > 1 and isinstance(block[1], list) and block[1] and _is_int(block[1][0]):
            snap.original_price_micros = block[1][0]

    if snap.original_price_micros is None:
        alt = _first(datasets, P_ORIGINAL_ALT, _is_int)
        if alt:
            snap.original_price_micros = alt

    end = _first(datasets, P_SALE_END_ALT, _is_int)
    if end and now < end < now + 60 * 86400:  # only accept a sane future timestamp
        snap.sale_ends_at = end

    # Fall back to JSON-LD only when the embedded data had no price at all.
    if snap.current_price_micros is None and snap.jsonld_price_micros is not None:
        snap.current_price_micros = snap.jsonld_price_micros
        snap.currency = snap.jsonld_currency

    if snap.current_price_micros is None:
        snap.error = "price_not_found"
        return snap

    # Cross-check: if both sources exist and disagree, refuse to guess.
    # (JSON-LD may legitimately show the list price during a sale, so matching
    # the struck-through price is also accepted.)
    def _close(a: Optional[int], b: Optional[int]) -> bool:
        return a is not None and b is not None and abs(a - b) <= 10_000

    if snap.jsonld_price_micros is not None and not (
        _close(snap.jsonld_price_micros, snap.current_price_micros)
        or _close(snap.jsonld_price_micros, snap.original_price_micros)
    ):
        snap.error = "price_conflict_jsonld"
        return snap

    snap.ok = True
    return snap


class PlayClient:
    def __init__(self, lang: str = "en", delay_seconds: float = 1.0, timeout: int = 20, retries: int = 2):
        self.lang = lang
        self.delay = delay_seconds
        self.timeout = timeout
        self.retries = retries
        self._last_request = 0.0
        self.requests_made = 0

    def _throttle(self) -> None:
        wait = self.delay - (time.monotonic() - self._last_request)
        if wait > 0:
            time.sleep(wait)
        self._last_request = time.monotonic()

    def fetch(self, package_id: str, country: str) -> PlaySnapshot:
        url = f"{canonical_play_url(package_id)}&hl={self.lang}&gl={country.upper()}"
        now = int(time.time())
        last_error = "unknown"
        status = 0
        for attempt in range(self.retries + 1):
            self._throttle()
            self.requests_made += 1
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept-Language": self.lang})
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    page = resp.read().decode("utf-8", errors="replace")
                return parse_listing(page, package_id, country, url, now)
            except urllib.error.HTTPError as e:
                status = e.code
                if e.code == 404:
                    return PlaySnapshot(package_id, country, now, url, ok=False, http_status=404, error="not_found")
                last_error = f"http_{e.code}"
                if e.code not in (429, 500, 502, 503, 504):
                    break
            except Exception as e:  # network errors, timeouts
                last_error = type(e).__name__
            time.sleep(min(30, 3 * (attempt + 1)))
        return PlaySnapshot(package_id, country, now, url, ok=False, http_status=status, error=last_error)

    def fetch_developer_apps(self, developer_path: str, country: str) -> tuple[bool, list[str], Optional[str]]:
        """Read a developer's Play page and return the package IDs it links to."""
        sep = "&" if "?" in developer_path else "?"
        url = f"https://play.google.com{developer_path}{sep}hl={self.lang}&gl={country.upper()}"
        for attempt in range(self.retries + 1):
            self._throttle()
            self.requests_made += 1
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept-Language": self.lang})
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    return True, parse_developer_apps(resp.read().decode("utf-8", errors="replace")), None
            except urllib.error.HTTPError as e:
                if e.code not in (429, 500, 502, 503, 504):
                    return False, [], f"http_{e.code}"
                error = f"http_{e.code}"
            except Exception as e:
                error = type(e).__name__
            time.sleep(min(30, 3 * (attempt + 1)))
        return False, [], error
