"""Core data structures for the deals pipeline.

Prices are stored as integer micros (1 USD = 1_000_000 micros), the same unit
Google Play uses internally, so we never lose precision with floats.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Status(str, Enum):
    """Internal verification states. These are NOT the user-facing categories."""

    DISCOVERED = "DISCOVERED"
    PENDING_VERIFICATION = "PENDING_VERIFICATION"
    VERIFIED_FREE = "VERIFIED_FREE"
    VERIFIED_DISCOUNT = "VERIFIED_DISCOUNT"
    EXPIRED = "EXPIRED"
    REJECTED = "REJECTED"
    VERIFICATION_FAILED = "VERIFICATION_FAILED"
    NEEDS_RECHECK = "NEEDS_RECHECK"


VERIFIED_STATES = {Status.VERIFIED_FREE, Status.VERIFIED_DISCOUNT}


class Category(str, Enum):
    APPS = "APPS"
    GAMES = "GAMES"
    WATCH_FACES = "WATCH_FACES"


@dataclass
class Candidate:
    """A raw lead produced by a connector. Never trusted on its own."""

    package_id: str
    source_id: str
    source_url: str
    seen_at: int  # epoch seconds
    claimed_title: Optional[str] = None


@dataclass
class PlaySnapshot:
    """What the Google Play listing said at one moment, for one country."""

    package_id: str
    country: str
    fetched_at: int
    url: str
    ok: bool
    http_status: int = 0
    error: Optional[str] = None
    title: Optional[str] = None
    developer: Optional[str] = None
    developer_url: Optional[str] = None  # path of the developer's Play page
    icon_url: Optional[str] = None
    genre_id: Optional[str] = None
    current_price_micros: Optional[int] = None
    original_price_micros: Optional[int] = None  # Play's struck-through price, if any
    currency: Optional[str] = None
    sale_ends_at: Optional[int] = None  # epoch seconds, only if Play states it
    has_iap: bool = False
    jsonld_price_micros: Optional[int] = None  # independent cross-check
    jsonld_currency: Optional[str] = None


@dataclass
class Verdict:
    status: Status
    method: str
    reason: str
    original_price_micros: Optional[int] = None
    discount_percent: Optional[int] = None


@dataclass
class SourceRef:
    source_id: str
    url: str
    first_seen: int
    last_seen: int


@dataclass
class DealRecord:
    """One product in one country. The unit of deduplication."""

    package_id: str
    country: str
    status: Status = Status.DISCOVERED
    title: Optional[str] = None
    developer: Optional[str] = None
    developer_url: Optional[str] = None
    icon_url: Optional[str] = None
    genre_id: Optional[str] = None
    category: Optional[Category] = None
    currency: Optional[str] = None
    current_price_micros: Optional[int] = None
    original_price_micros: Optional[int] = None
    discount_percent: Optional[int] = None
    has_iap: bool = False
    first_seen: int = 0
    last_checked: int = 0
    last_success: int = 0
    last_source_seen: int = 0
    deal_started_at: Optional[int] = None
    expires_at: Optional[int] = None
    event_id: Optional[str] = None
    fail_count: int = 0
    last_error: Optional[str] = None
    verify_method: Optional[str] = None
    last_reason: Optional[str] = None
    live_status: Optional[Status] = None  # the verified type while a deal is live
    sources: list[SourceRef] = field(default_factory=list)
    evidence: list[dict] = field(default_factory=list)
    price_history: list[dict] = field(default_factory=list)

    @property
    def key(self) -> str:
        return f"{self.package_id}|{self.country}"
